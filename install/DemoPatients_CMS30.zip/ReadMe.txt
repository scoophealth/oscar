Physician Group                    : McMaster Hospital
CMS Vendor, Product & Version      : OSCARMcMaster, OSCARMcMaster ver2.1
Application Support Contact        : Jay Gallagher (905-525-9140 ext28517, jay@jayweb.ca)
Media type                         : Hard Disk
Number of media                    : 1
Date and Time stamp                : 2010-08-07 04:05:54 PM
Total byte count of export files(s): 182245
Total patients files extracted     : 13
Number of errors                   : 2 (See ExportEvent.log for detail)
Patient ID range                   : 1-13
