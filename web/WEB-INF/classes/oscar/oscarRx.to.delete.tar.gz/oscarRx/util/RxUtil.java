package oscar.oscarRx.util;
import java.text.*;
import java.util.*;

public class RxUtil
{
    private static String defaultPattern = "yyyy/MM/dd";
    private static Locale locale = Locale.CANADA;

    public static Date StringToDate(String Expression)
    {
        return StringToDate(Expression, defaultPattern);
    }
    public static Date StringToDate(String Expression, String pattern)
    {
        try
        {
            SimpleDateFormat df = new SimpleDateFormat(pattern, locale);

            return df.parse(Expression);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static String DateToString(Date Expression)
    {
        return DateToString(Expression, defaultPattern);
    }

    public static String DateToString(Date Expression, String pattern)
    {
        if(Expression!=null)
        {
            SimpleDateFormat df = new SimpleDateFormat(pattern, locale);

            return df.format(Expression);
        }
        else
        {
            return "";
        }
    }

    public static Date Today()
    {
        return (java.util.GregorianCalendar.getInstance().getTime());
    }


    public static int BoolToInt(boolean Expression)
    {
        if (Expression==true)
        {
            return 1;
        } else
        {
            return 0;
        }
    }

    public static boolean IntToBool(int Expression)
    {
        return (Expression!=0);
    }

    public static String FloatToString(float value)
    {
        Float f = new Float(value);

        java.text.NumberFormat fmt = java.text.NumberFormat.getNumberInstance();

        String s = fmt.format(f.doubleValue());

        return s;
    }

    public static float StringToFloat(String value)
    {
        return Float.parseFloat(value);
    }

    public static Object IIf(boolean Expression, Object TruePart, Object FalsePart)
    {
        if (Expression==true)
        {
            return TruePart;
        } else
        {
            return FalsePart;
        }
    }

    public static String joinArray(Object[] array)
    {
        String ret = "";
        int i;
        for (i=0; i<array.length; i++)
        {
            ret += "'" + String.valueOf(array[i]) + "'";
            if(i < array.length - 1)
            {
                ret += ", ";
            }
        }

        return ret;
    }

    public static String replace(String expression, String searchFor, String replaceWith)
    {
        if(expression!=null)
        {
            StringBuffer buf = new StringBuffer(expression);

            int pos = -1;

            while(true)
            {
                pos = buf.indexOf(searchFor, pos);

                if(pos>-1)
                {
                    buf.delete(pos, pos+searchFor.length());
                    buf.insert(pos, replaceWith);

                    pos += replaceWith.length();
                }
                else
                {
                    break;
                }
            }

            return buf.toString();
        }
        else
        {
            return null;
        }
    }
}