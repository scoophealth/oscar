package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;

import oscar.oscarRx.util.RxUtil;


public final class RxUpdateFavoriteAction extends Action {


    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException {

            // Extract attributes we will need
            Locale locale = getLocale(request);
            MessageResources messages = getResources();

            // Setup variables
            ActionErrors errors = new ActionErrors();

            RxUpdateFavoriteForm frm = (RxUpdateFavoriteForm)form;
            int favId = Integer.parseInt(frm.getFavoriteId());

            RxPrescriptionData.Favorite fav = new RxPrescriptionData().getFavorite(favId);

            fav.setFavoriteName(frm.getFavoriteName());
            fav.setCustomName(frm.getCustomName());
            fav.setTakeMin(RxUtil.StringToFloat(frm.getTakeMin()));
            fav.setTakeMax(RxUtil.StringToFloat(frm.getTakeMax()));
            fav.setFrequencyCode(frm.getFrequencyCode());
            fav.setDuration(frm.getDuration());
            fav.setDurationUnit(frm.getDurationUnit());
            fav.setQuantity(frm.getQuantity());
            fav.setRepeat(Integer.parseInt(frm.getRepeat()));
            fav.setNosubs(frm.getNosubs());
            fav.setPrn(frm.getPrn());
            fav.setSpecial(frm.getSpecial());

            fav.Save();

            return (mapping.findForward("success"));
    }
}