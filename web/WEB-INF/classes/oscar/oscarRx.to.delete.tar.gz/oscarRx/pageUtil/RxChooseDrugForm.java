package oscar.oscarRx.pageUtil;


import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class RxChooseDrugForm extends ActionForm {


    private String demographicNo = null;
    private String BN = null;
    private String GN = null;

    public String getDemographicNo()
    {
	return (this.demographicNo);
    }

    public void setDemographicNo(String demographicNo)
    {
        this.demographicNo = demographicNo;
    }

    public String getBN()
    {
        return (this.BN);
    }

    public void setBN(String BN)
    {
        this.BN = BN;
    }

    public String getGN()
    {
        return (this.GN);
    }

    public void setGN(String GN)
    {
        this.GN = GN;
    }

    /**
     * Reset all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.demographicNo = null;
        this.BN=null;
        this.GN=null;
    }


    /**
     * Validate the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();

        return errors;

    }
}
