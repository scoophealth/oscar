package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;
import oscar.oscarRx.util.*;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class RxWriteScriptAction extends Action
{
    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException
    {
        // Extract attributes we will need
        Locale locale = getLocale(request);
        MessageResources messages = getResources();

        // Setup variables
        ActionErrors errors = new ActionErrors();
        RxWriteScriptForm frm = (RxWriteScriptForm)form;

        String fwd = "refresh";

        oscar.oscarRx.pageUtil.RxSessionBean bean =
                (oscar.oscarRx.pageUtil.RxSessionBean)request.getSession().getAttribute("RxSessionBean");
        if(bean==null)
        {
            response.sendRedirect("error.html");
            return null;
        }

        if(frm.getAction().startsWith("update"))
        {
            RxDrugData drugData = new RxDrugData();

            RxPrescriptionData.Prescription rx = bean.getStashItem(bean.getStashIndex());

            if(frm.getGCN_SEQNO() != 0) // not custom
            {
                if(frm.getBrandName().equals(rx.getBrandName())==false)
                {
                    rx.setBrandName(frm.getBrandName());
                    rx.setGCN_SEQNO(drugData.getGCNList(frm.getGenericName(), frm.getBrandName())[0].getGCN_SEQNO());
                }
                else
                {
                    rx.setGCN_SEQNO(frm.getGCN_SEQNO());
                }
            }
            else // custom
            {
                rx.setBrandName(null);
                rx.setGCN_SEQNO(0);
                rx.setCustomName(frm.getCustomName());
            }

            rx.setRxDate(RxUtil.StringToDate(frm.getRxDate()));

            rx.setTakeMin(frm.getTakeMinFloat());
            rx.setTakeMax(frm.getTakeMaxFloat());
            rx.setFrequencyCode(frm.getFrequencyCode());
            rx.setDuration(frm.getDuration());
            rx.setDurationUnit(frm.getDurationUnit());
            rx.setQuantity(frm.getQuantity());
            rx.setRepeat(frm.getRepeat());
            rx.setNosubs(frm.getNosubs());
            rx.setPrn(frm.getPrn());
            rx.setSpecial(frm.getSpecial());

            bean.setStashItem(bean.getStashIndex(), rx);

            rx=null;

            if(frm.getAction().equals("update"))
            {
                fwd = "refresh";
            }
            if(frm.getAction().equals("updateAddAnother"))
            {
                fwd = "addAnother";
            }
            if(frm.getAction().equals("updateAndPrint"))
            {
                int i;

                for(i=0; i<bean.getStashSize(); i++)
                {
                    rx = bean.getStashItem(i);
                    rx.Save();
                    rx = null;
                }

                fwd = "viewScript";
            }
        }

        return mapping.findForward(fwd);
    }
}