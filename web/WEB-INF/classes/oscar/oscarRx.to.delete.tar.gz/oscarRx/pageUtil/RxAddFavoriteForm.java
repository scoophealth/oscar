package oscar.oscarRx.pageUtil;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public final class RxAddFavoriteForm extends ActionForm {

    private String drugId = null;
    private String stashId = null;
    private String favoriteName = null;
    private String returnParams = null;

    public String getDrugId()
    {
	return (this.drugId);
    }

    public void setDrugId(String drugId)
    {
        this.drugId = drugId;
    }

    public String getStashId()
    {
        return (this.stashId);
    }

    public void setStashId(String stashId)
    {
        this.stashId = stashId;
    }

    public String getFavoriteName()
    {
        return (this.favoriteName);
    }

    public void setFavoriteName(String favoriteName)
    {
        this.favoriteName = favoriteName;
    }

    public String getReturnParams()
    {
        return (this.returnParams);
    }

    public void setReturnParams(String RHS)
    {
        this.returnParams = RHS;
    }

    /**
     * Reset all properties to their default values.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
        this.drugId = null;
        this.stashId = null;
        this.favoriteName = null;
        this.returnParams =  null;
    }

    /**
     * Validate the properties that have been set from this HTTP request,
     * and return an <code>ActionErrors</code> object that encapsulates any
     * validation errors that have been found.  If no errors are found, return
     * <code>null</code> or an <code>ActionErrors</code> object with no
     * recorded error messages.
     *
     * @param mapping The mapping used to select this instance
     * @param request The servlet request we are processing
     */
    public ActionErrors validate(ActionMapping mapping,
                                 HttpServletRequest request) {

        ActionErrors errors = new ActionErrors();

        return errors;

    }
}
