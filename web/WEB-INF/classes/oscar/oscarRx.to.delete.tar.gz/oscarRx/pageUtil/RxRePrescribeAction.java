package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class RxRePrescribeAction extends Action {


    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException {

            // Extract attributes we will need
            Locale locale = getLocale(request);
            MessageResources messages = getResources();

            // Setup variables
            ActionErrors errors = new ActionErrors();

            oscar.oscarRx.pageUtil.RxSessionBean bean =
                    (oscar.oscarRx.pageUtil.RxSessionBean)request.getSession().getAttribute("RxSessionBean");
            if(bean==null)
            {
                response.sendRedirect("error.html");
                return null;
            }

            try
            {
                RxPrescriptionData rxData =
                        new RxPrescriptionData();

                String drugList = ((RxDrugListForm)form).getDrugList();
                String[] drugArr = drugList.split(",");

                int drugId;
                int i;

                for(i=0;i<drugArr.length;i++)
                {
                    try
                    {
                        drugId = Integer.parseInt(drugArr[i]);
                    } catch (Exception e) { break; }

                    // get original drug
                    RxPrescriptionData.Prescription oldRx =
                            rxData.getPrescription(drugId);

                    // create copy of Prescription
                    RxPrescriptionData.Prescription rx =
                            rxData.newPrescription(bean.getProviderNo(), bean.getDemographicNo(), oldRx);

                    bean.setStashIndex(bean.addStashItem(rx));
                }
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
            }

            return (mapping.findForward("success"));
    }
}
