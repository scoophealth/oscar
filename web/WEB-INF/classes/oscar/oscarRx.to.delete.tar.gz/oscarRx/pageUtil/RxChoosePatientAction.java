package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class RxChoosePatientAction extends Action {


    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException {

        // Extract attributes we will need
        Locale locale = getLocale(request);
        MessageResources messages = getResources();

        // Setup variables
        ActionErrors errors = new ActionErrors();

        RxChoosePatientForm frm = (RxChoosePatientForm)form;

        // Setup bean
        RxSessionBean bean;

        if(request.getSession().getAttribute("RxSessionBean")!=null)
        {
            bean = (oscar.oscarRx.pageUtil.RxSessionBean)request.getSession().getAttribute("RxSessionBean");

            if((bean.getProviderNo() != frm.getProviderNo())
                || (bean.getDemographicNo() != Integer.parseInt(frm.getDemographicNo())))
            {
                bean = new RxSessionBean();
            }
        }
        else
        {
            bean = new RxSessionBean();
        }

        bean.setProviderNo(frm.getProviderNo());
        bean.setDemographicNo(Integer.parseInt(frm.getDemographicNo()));

        request.getSession().setAttribute("RxSessionBean", bean);

        RxPatientData rx = null;
        RxPatientData.Patient patient = null;
        try
        {
            rx = new RxPatientData();
            patient = rx.getPatient(bean.getDemographicNo());
        }
        catch (java.sql.SQLException ex)
        {
            throw new ServletException(ex);
        }

        if(patient!=null)
        {
            request.getSession().setAttribute("Patient", patient);
            return (mapping.findForward("success"));

        } else //no records found
        {
            response.sendRedirect("error.html");
            return null;
        }
    }
}