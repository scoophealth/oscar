package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class RxChooseDrugAction extends Action {


    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException {

            // Extract attributes we will need
            Locale locale = getLocale(request);
            MessageResources messages = getResources();

            // Setup variables
            ActionErrors errors = new ActionErrors();

            oscar.oscarRx.pageUtil.RxSessionBean bean =
                    (oscar.oscarRx.pageUtil.RxSessionBean)request.getSession().getAttribute("RxSessionBean");
            if(bean==null)
            {
                response.sendRedirect("error.html");
                return null;
            }

            try
            {
                RxChooseDrugForm frm = (RxChooseDrugForm)form;
                RxPrescriptionData rxData = new RxPrescriptionData();
                RxDrugData drugData = new RxDrugData();

                // create Prescription
                RxPrescriptionData.Prescription rx =
                        rxData.newPrescription(bean.getProviderNo(), bean.getDemographicNo());

                String GN = frm.getGN();
                String BN = frm.getBN();

                if(GN==null)
                {
                    GN = drugData.getGenericFromBrand(BN);
                }
                if(BN==null)
                {
                    String brands[] = drugData.getBrandsFromGeneric(GN);

                    if(brands.length>0)
                    {
                        BN = brands[0];
                    }
                }

                if(BN!=null)
                {
                    rx.setBrandName(BN);
                    rx.setGCN_SEQNO(drugData.getGCNList(GN, BN)[0].getGCN_SEQNO());
                }
                else // Custom
                {
                    rx.setBrandName(null);
                    rx.setCustomName("");
                    rx.setGCN_SEQNO(0);
                }

                rx.setRxDate(oscar.oscarRx.util.RxUtil.Today());
                rx.setEndDate(null);

                rx.setTakeMin(1);
                rx.setTakeMax(1);
                rx.setFrequencyCode("OID");
                rx.setDuration("1");
                rx.setDurationUnit("D");

                bean.setStashIndex(bean.addStashItem(rx));
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
            }

            return (mapping.findForward("success"));
    }
}