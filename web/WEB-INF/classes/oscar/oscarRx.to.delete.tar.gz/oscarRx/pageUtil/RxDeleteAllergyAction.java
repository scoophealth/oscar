package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.util.MessageResources;


public final class RxDeleteAllergyAction extends Action {

    public ActionForward perform(ActionMapping mapping,
				 ActionForm form,
				 HttpServletRequest request,
				 HttpServletResponse response)
	throws IOException, ServletException {

            // Extract attributes we will need
            Locale locale = getLocale(request);
            MessageResources messages = getResources();

            // Setup variables
            ActionErrors errors = new ActionErrors();

            // Add allergy

            int id = Integer.parseInt(request.getParameter("ID"));

            RxPatientData.Patient patient = (RxPatientData.Patient)request.getSession().getAttribute("Patient");

            patient.deleteAllergy(id);

            ((RxSessionBean)request.getSession().getAttribute("RxSessionBean")).clearDAM();

            return (mapping.findForward("success"));
    }
}