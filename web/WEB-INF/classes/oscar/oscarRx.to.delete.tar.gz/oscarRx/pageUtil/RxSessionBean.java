package oscar.oscarRx.pageUtil;

import oscar.oscarRx.data.*;

import java.util.*;

public class RxSessionBean
{
    private String providerNo = null;
    private int demographicNo = 0;

    private ArrayList stash = new ArrayList();
    private int stashIndex = -1;

    private RxInteractionsData.DrugDrugInteraction[] DDI = {};
    private boolean boolDDI = false;

    private RxAllergyData.Reaction[] DAM = {};
    private boolean boolDAM = false;

    //--------------------------------------------------------------------------

    public String getProviderNo()
    {
        return this.providerNo;
    }
    public void setProviderNo(String RHS)
    {
        this.providerNo = RHS;
    }

    public int getDemographicNo()
    {
        return this.demographicNo;
    }
    public void setDemographicNo(int RHS)
    {
        this.demographicNo = RHS;
    }

    //--------------------------------------------------------------------------

    public int getStashIndex()
    {
        return this.stashIndex;
    }
    public void setStashIndex(int RHS)
    {
        if(RHS < this.getStashSize())
        {
            this.stashIndex = RHS;
        }
    }

    public int getStashSize()
    {
        return this.stash.size();
    }

    public RxPrescriptionData.Prescription[] getStash()
    {
        RxPrescriptionData.Prescription[] arr = {};

        arr = (RxPrescriptionData.Prescription[])stash.toArray(arr);

        return arr;
    }

    public RxPrescriptionData.Prescription getStashItem(int index)
    {
        return (RxPrescriptionData.Prescription)stash.get(index);
    }

    public void setStashItem(int index, RxPrescriptionData.Prescription item)
    {
        this.clearDAM();
        this.clearDDI();
        stash.set(index, item);
    }

    public int addStashItem(RxPrescriptionData.Prescription item)
    {
        this.clearDDI();
        this.clearDAM();
        int ret = -1;

        int i;
        RxPrescriptionData.Prescription rx;

        //check to see if the item already exists
        //by checking for duplicate brandname and gcn seq no
        //if it exists, return it, else add it.
        for(i=0;i<this.getStashSize(); i++)
        {
            rx = this.getStashItem(i);

            if(item.isCustom())
            {
                if(rx.isCustom() && rx.getCustomName() !=null && item.getCustomName() != null)
                {
                    if(rx.getCustomName().equals(item.getCustomName()))
                    {
                        ret = i;
                        break;
                    }
                }
            }
            else
            {
                if(rx.getBrandName()!=null && item.getBrandName() !=null)
                {
                    if(rx.getBrandName().equals(item.getBrandName())
                    && rx.getGCN_SEQNO()==item.getGCN_SEQNO())
                    {
                        ret = i;
                        break;
                    }
                }
            }
        }

        if(ret>-1)
        {
            return ret;
        }
        else
        {
            stash.add(item);
            return this.getStashSize()-1;
        }
    }

    public void removeStashItem(int index)
    {
        this.clearDDI();
        this.clearDAM();
        stash.remove(index);
    }

    public void clearStash()
    {
        this.clearDDI();
        this.clearDAM();
        stash = new ArrayList();
    }

    //--------------------------------------------------------------------------

    public RxInteractionsData.DrugDrugInteraction[] getDDI()
        throws java.sql.SQLException
    {
        if(!this.boolDDI)
        {
            java.util.ArrayList gcnList = new java.util.ArrayList();
            Integer[] gcnArray = {};

            RxPatientData.Patient patient = new RxPatientData().getPatient(this.getDemographicNo());
            RxPrescriptionData.Prescription[] drugs = patient.getPrescribedDrugs();

            int i;
            for(i=0; i<drugs.length; i++)
            {
                if(drugs[i].getGCN_SEQNO() != 0)
                {
                    if(drugs[i].isCurrent())
                    {
                        gcnList.add(new Integer(drugs[i].getGCN_SEQNO()));
                    }
                }
            }

            for(i=0; i<this.getStashSize(); i++)
            {
                if(this.getStashItem(i).getGCN_SEQNO() != 0)
                {
                    gcnList.add(new Integer(this.getStashItem(i).getGCN_SEQNO()));
                }
            }

            gcnArray = (Integer[])gcnList.toArray(gcnArray);

            this.DDI = new RxInteractionsData().getDDI(gcnArray);
            this.boolDDI = true;
        }
        return this.DDI;
    }

    public String getDDIColor()
        throws java.sql.SQLException
    {
        String ret = "buttonface";

        if(this.DDI.length>0)
        {
            RxInteractionsData.DrugDrugInteraction[] ddi = this.getDDI();
            int i;
            int sl=10;

            for(i=0; i<ddi.length; i++)
            {
                if(ddi[i].getSeverityLevel()<sl)
                {
                    sl = ddi[i].getSeverityLevel();
                }
            }

            switch(sl)
            {
                case 1:
                {
                    ret = "red";
                    break;
                }
                case 2:
                {
                    ret = "orange";
                    break;
                }
                case 3:
                {
                    ret = "yellow";
                    break;
                }
            }
        }

        return ret;
    }

    public void clearDDI()
    {
        this.DDI = new RxInteractionsData.DrugDrugInteraction[]{};
        this.boolDDI = false;
    }

    //--------------------------------------------------------------------------

    public RxAllergyData.Reaction[] getDAM()
        throws java.sql.SQLException
    {
        if(!this.boolDAM)
        {
            java.util.ArrayList gcnList = new java.util.ArrayList();
            Integer[] gcnArray = {};

            RxPatientData.Patient patient = new RxPatientData().getPatient(this.getDemographicNo());

            int i;

            for(i=0; i<this.getStashSize(); i++)
            {
                if(this.getStashItem(i).getGCN_SEQNO() != 0)
                {
                    gcnList.add(new Integer(this.getStashItem(i).getGCN_SEQNO()));
                }
            }

            gcnArray = (Integer[])gcnList.toArray(gcnArray);

            this.DAM = new RxAllergyData().getReactions(gcnArray, patient);
            this.boolDAM = true;
        }
        return this.DAM;
    }

    public String getDAMColor()
        throws java.sql.SQLException
    {
        String ret = "buttonface";

        if(this.getDAM().length>0)
        {
            RxAllergyData.Reaction[] dam = this.getDAM();
            int i;
            int sl=10;

            for(i=0; i<dam.length; i++)
            {
                if(dam[i].getSeverity()<sl)
                {
                    sl = dam[i].getSeverity();
                }
            }

            switch(sl)
            {
                case 1:
                {
                    ret = "red";
                    break;
                }
                case 2:
                {
                    ret = "orange";
                    break;
                }
                case 3:
                {
                    ret = "yellow";
                    break;
                }
            }
        }

        return ret;
    }

    public void clearDAM()
    {
        this.DAM = new RxAllergyData.Reaction[]{};
        this.boolDAM = false;
    }


    public boolean isValid()
    {
        if(this.demographicNo > 0
                && this.providerNo != null
                && this.providerNo.length() > 0)
        {
            return true;
        }
        return false;
    }
}