package oscar.oscarRx.data;
import oscar.oscarDB.*;

import java.util.*;
import java.sql.*;
import java.io.*;

public class RxLogonData
{
    /* Patient Search */
    public boolean LogonVerify(String username, String password)
    {
        String pWord= null;
        boolean success= false;
	try
	{
            DBHandler db = new DBHandler("osrx");
            ResultSet rs;

            rs = db.GetSQL("SELECT password "
                + "FROM security WHERE user_name='" + username + "'");

            if(rs.next())
            {
              pWord = rs.getString("password");
              if (pWord.compareTo(password)==0)
              {
                success =true;
              }
            }
            else
            {
              success =false;
            }

            rs.close();
            db.CloseConn();


	} catch (Exception e)
	{
            System.out.println(e.getMessage());
	}

	return success;
    }

        /* Patient Search */
    public String GetProviderNo(String username)
    {
        String provider_no= null;


        try
	{
            DBHandler db = new DBHandler("osrx");
            ResultSet rs;

            rs = db.GetSQL("SELECT provider_no "
                + " FROM security WHERE user_name LIKE '"
                + username + "'");

            if(rs.next())
            {
              provider_no = rs.getString("provider_no");
            }
            else
            {
              provider_no =null;
            }

            rs.close();
            db.CloseConn();


	} catch (Exception e)
	{
            System.out.println(e.getMessage());
	}

	return provider_no;
    }


}
