package oscar.oscarRx.data;

import oscar.util.UtilXML;
import oscar.oscarDB.*;
import oscar.oscarRx.util.*;

import java.util.*;
import java.sql.*;

import javax.xml.parsers.*;
import org.w3c.dom.*;

public class RxDrugData
{
    public String[] DrugSearchByBrandName(String brandName)
    {
        String[] arr = {};

        if(brandName.length()>0)
        {
            ArrayList lst = new ArrayList();

            String newBN = oscar.oscarRx.util.RxUtil.replace(brandName, "'", "''");

            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;

                rs = db.GetSQL("SELECT DISTINCT BN FROM IDDF WHERE BN LIKE '" + newBN + "%' ORDER BY BN");

                while(rs.next())
                {
                    lst.add(rs.getString("BN"));
                }

                rs.close();
                db.CloseConn();

                arr = (String[])lst.toArray(arr);

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }
        }

	return arr;
    }

    public String[] DrugSearchByGenericName(String genericName)
    {
        String[] arr = {};

        if(genericName.length()>0)
        {
            ArrayList lst = new ArrayList();

            String newGN = oscar.oscarRx.util.RxUtil.replace(genericName, "'", "''");
            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;

                rs = db.GetSQL("SELECT DISTINCT CGNN FROM IDDF WHERE CGNN LIKE '" + newGN + "%' ORDER BY CGNN");

                while(rs.next())
                {
                    lst.add(rs.getString("CGNN"));
                }

                rs.close();
                db.CloseConn();

                arr = (String[])lst.toArray(arr);

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }
        }

	return arr;
    }

    public String getGenericFromBrand(String brandName)
    {
        String GN = null;

        String newBN = oscar.oscarRx.util.RxUtil.replace(brandName, "'", "''");
        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;

            rs = db.GetSQL("SELECT DISTINCT CGNN FROM IDDF WHERE BN = '" + newBN + "'");

            if(rs.next())
            {
                GN = rs.getString("CGNN");
            }

            rs.close();
            db.CloseConn();

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return GN;
    }

    public String[] getBrandsFromGeneric(String genericName)
    {
        String[] arr = {};
        ArrayList lst = new ArrayList();

        String newGN = oscar.oscarRx.util.RxUtil.replace(genericName, "'", "''");

        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;

            rs = db.GetSQL("SELECT DISTINCT BN FROM IDDF "
            + "WHERE CGNN = '" + newGN + "' ORDER BY BN");

            while(rs.next())
            {
                lst.add(rs.getString("BN"));
            }

            rs.close();
            db.CloseConn();

            arr = (String[])lst.toArray(arr);
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public String getGenericName(int GCN_SEQNO)
    {
        String ret = null;

        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;

            rs = db.GetSQL("SELECT DISTINCT CGNN FROM IDDF WHERE GCN_SEQNO = " + GCN_SEQNO);

            if(rs.next())
            {
                ret = rs.getString("CGNN");
            }

            rs.close();
            db.CloseConn();

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return ret;
    }

    public GCN[] getGCNList(String genericName)
    {
        return getGCNList(genericName, "");
    }

    public GCN[] getGCNList(String genericName, String brandName)
    {
        GCN[] arr = {};
        ArrayList lst = new ArrayList();

        String newGN = oscar.oscarRx.util.RxUtil.replace(genericName, "'", "''");
        String newBN = oscar.oscarRx.util.RxUtil.replace(brandName, "'", "''");

        if(genericName!=null)
        {
            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;
                GCN g;
                String sql;

                if(brandName==null || brandName.length()==0)
                {
                    sql = "SELECT DISTINCT BN, GCN_SEQNO FROM IDDF "
                    + "WHERE CGNN = '" + newGN + "' ORDER BY BN";
                } else
                {
                    sql = "SELECT DISTINCT BN, GCN_SEQNO FROM IDDF "
                    + "WHERE CGNN = '" + newGN + "' AND BN = '" + newBN + "'";
                }

                rs = db.GetSQL(sql);

                while(rs.next())
                {
                    g = new GCN(rs.getString("BN"), rs.getInt("GCN_SEQNO"));
                    lst.add(g);
                }

                rs.close();
                db.CloseConn();

                arr = (GCN[])lst.toArray(arr);
            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }
        }

        return arr;
    }

    public GCN getGCN(String brandName, int GCN_SEQNO)
    {
        return new GCN(brandName, GCN_SEQNO);
    }

    public class GCN
    {
        String BN = null;
        String GN = null;
        int GCN_SEQNO = 0;
        String Strength = null;
        String DoseForm = null;
        String Route = null;
        String HIC3 = null;

        public GCN(String BN, int GCN_SEQNO)
        {
            this.BN = BN;
            this.GCN_SEQNO = GCN_SEQNO;
        }

        public String getBrandName()
        {
            return this.BN;
        }

        public String getGenericName()
        {
            loadDFR();
            return this.GN;
        }

        public int getGCN_SEQNO()
        {
            return this.GCN_SEQNO;
        }

        public String getStrength()
        {
            loadDFR();
            return this.Strength;
        }

        public String getDoseForm()
        {
            loadDFR();
            return this.DoseForm;
        }

        public String getRoute()
        {
            loadDFR();
            return this.Route;
        }

        public String getHIC3()
        {
            loadDFR();
            return this.HIC3;
        }

        public String getDFRDisplay()
        {
            loadDFR();
            return (this.Strength + " / " + this.DoseForm + " / " + this.Route);
        }

        private void loadDFR()
        {
            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;

                rs = db.GetSQL("SELECT STR, RDOSED1.GCDF_DESC, RROUTED2.GCRT_DESC, HIC3 "
                    + "FROM RGCNSEQ3 INNER JOIN RDOSED1 "
                    + "ON RGCNSEQ3.GCDF = RDOSED1.GCDF INNER JOIN RROUTED2 "
                    + "ON RGCNSEQ3.GCRT = RROUTED2.GCRT "
                    + "WHERE GCN_SEQNO = " + this.GCN_SEQNO);

                if(rs.next())
                {
                    this.Strength = rs.getString("STR");
                    this.DoseForm = rs.getString("GCDF_DESC");
                    this.Route = rs.getString("GCRT_DESC");
                    this.HIC3 = rs.getString("HIC3");
                }

                rs.close();

                rs = db.GetSQL("SELECT DISTINCT CGNN FROM IDDF WHERE GCN_SEQNO = " + this.GCN_SEQNO);

                if(rs.next())
                {
                    this.GN = rs.getString("CGNN");
                }

                rs.close();

                db.CloseConn();

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }
        }
    }

    public String getDrugInfo(String genericName)
            throws java.sql.SQLException
    {
        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;
            String sql;
            String s;

            Document doc = UtilXML.newDocument();
            Element root = UtilXML.addNode(doc, "DrugInfo");

            Element brandInfo = UtilXML.addNode(root, "BrandInfo");
            Element hicInfo =   UtilXML.addNode(root, "IngredientInfo");
            Element ddiInfo =   UtilXML.addNode(root, "DrugDrugInteractionInfo");
            Element damInfo =   UtilXML.addNode(root, "AllergyInfo");
            Element disInfo =   UtilXML.addNode(root, "DiseaseInfo");
            Element pemInfo =   UtilXML.addNode(root, "PatientEducationInfo");
            Element dfimInfo =  UtilXML.addNode(root, "DrugFoodInfo");

            ArrayList gcnList = new ArrayList();

            ((Element)root).setAttribute("genericName", genericName);

/*  This SQL statement is split into two because it is too slow otherwise
            sql = "SELECT DISTINCT IDDF.BN, IDDF.GCN_SEQNO, "
                + "RGCNSEQ3.STR, RDOSED1.GCDF_DESC, RROUTED2.GCRT_DESC "
                + "FROM IDDF "
                + "INNER JOIN RGCNSEQ3 ON IDDF.GCN_SEQNO = RGCNSEQ3.GCN_SEQNO "
                + "INNER JOIN RDOSED1 ON RGCNSEQ3.GCDF = RDOSED1.GCDF "
                + "INNER JOIN RROUTED2 ON RGCNSEQ3.GCRT = RROUTED2.GCRT "
                + "WHERE IDDF.CGNN = '" + RxUtil.replace(genericName, "'", "''") + "' "
                + "ORDER BY BN, STR, GCDF_DESC, GCRT_DESC";
*/
            sql = "SELECT DISTINCT BN, GCN_SEQNO FROM IDDF "
                + "WHERE CGNN = '" + RxUtil.replace(genericName, "'", "''") + "' "
                + "ORDER BY BN, GCN_SEQNO";

            rs = db.GetSQL(sql);

            Element brand = null;
            String sBN = "";

            while(rs.next())
            {
                // Add Brand Info

                if(sBN.equals(rs.getString("BN"))==false)
                {
                    sBN = rs.getString("BN");
                    brand = UtilXML.addNode(brandInfo, "Brand");
                    brand.setAttribute("brandName", sBN);
                }

                int nGCN = rs.getInt("GCN_SEQNO");
                if(!(gcnList.contains(String.valueOf(nGCN))))
                {
                    gcnList.add(String.valueOf(nGCN));
                }

                Element DFR = UtilXML.addNode(brand, "DFR");
                ((Element)DFR).setAttribute("gcn_seqno", String.valueOf(nGCN));

                sql = "SELECT STR, RDOSED1.GCDF_DESC, RROUTED2.GCRT_DESC "
                    + "FROM RGCNSEQ3 INNER JOIN RDOSED1 "
                    + "ON RGCNSEQ3.GCDF = RDOSED1.GCDF INNER JOIN RROUTED2 "
                    + "ON RGCNSEQ3.GCRT = RROUTED2.GCRT "
                    + "WHERE RGCNSEQ3.GCN_SEQNO = " + nGCN;

                ResultSet rsDFR = db.GetSQL(sql);

                if(rsDFR.next())
                {
                    UtilXML.addNode(DFR, "Strength", rsDFR.getString("STR"));
                    UtilXML.addNode(DFR, "DosageForm", rsDFR.getString("GCDF_DESC"));
                    UtilXML.addNode(DFR, "Route", rsDFR.getString("GCRT_DESC"));
                }

                rsDFR.close();

                // Add Dosage Info
                ResultSet rsDos;

                Element dosage = UtilXML.addNode(DFR, "Dosage");
                Element adult = UtilXML.addNode(dosage, "Header");
                adult.setAttribute("text", "Adult");
                Element geriatric = UtilXML.addNode(dosage, "Header");
                geriatric.setAttribute("text", "Geriatric");
                Element pediatric = UtilXML.addNode(dosage, "Header");
                pediatric.setAttribute("text", "Pediatric");

                sql = "SELECT * FROM RMMADMA1 WHERE GCN_SEQNO = " + nGCN;
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    String sMin = rsDos.getString("MMA_MND") + " " + rsDos.getString("MMA_MNDU")
                        + " (" + rsDos.getString("MMA_MNU") + " " + rsDos.getString("MMA_MNUF") + ")";

                    String sMax = rsDos.getString("MMA_MXD") + " " + rsDos.getString("MMA_MXDU")
                        + " (" + rsDos.getString("MMA_MXU") + " " + rsDos.getString("MMA_MXUF") + ")";

                    Element min = UtilXML.addNode(adult, "Line", "Minimum: " + sMin);
                    Element max = UtilXML.addNode(adult, "Line", "Maximum: " + sMax);
                }
                rsDos.close();

                sql = "SELECT * FROM RMMARMA0 WHERE GCN_SEQNO = " + nGCN;
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    String sMin = rsDos.getString("MMAR_MND") + " " + rsDos.getString("MMAR_MNDU")
                        + " (" + rsDos.getString("MMAR_MNU") + " " + rsDos.getString("MMAR_MNUF") + ")";

                    String sMax = rsDos.getString("MMAR_MXD") + " " + rsDos.getString("MMAR_MXDU")
                        + " (" + rsDos.getString("MMAR_MXU") + " " + rsDos.getString("MMAR_MXUF") + ")";

                    Element min = UtilXML.addNode(adult, "Line", "Minimum Daily: " + sMin);
                    Element max = UtilXML.addNode(adult, "Line", "Maximum Daily: " + sMax);
                }
                rsDos.close();

                sql = "SELECT * FROM RMMGDMA0 WHERE GCN_SEQNO = " + nGCN;
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    String sMin = rsDos.getString("MMG_MND") + " " + rsDos.getString("MMG_MNDU")
                        + " (" + rsDos.getString("MMG_MNU") + " " + rsDos.getString("MMG_MNUF") + ")";

                    String sMax = rsDos.getString("MMG_MXD") + " " + rsDos.getString("MMG_MXDU")
                        + " (" + rsDos.getString("MMG_MXU") + " " + rsDos.getString("MMG_MXUF") + ")";

                    Element min = UtilXML.addNode(geriatric, "Line", "Minimum: " + sMin);
                    Element max = UtilXML.addNode(geriatric, "Line", "Maximum: " + sMax);
                }
                rsDos.close();

                sql = "SELECT * FROM RMMGRMA0 WHERE GCN_SEQNO = " + nGCN;
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    String sMin = rsDos.getString("MMGR_MND") + " " + rsDos.getString("MMGR_MNDU")
                        + " (" + rsDos.getString("MMGR_MNU") + " " + rsDos.getString("MMGR_MNUF") + ")";

                    String sMax = rsDos.getString("MMGR_MXD") + " " + rsDos.getString("MMGR_MXDU")
                        + " (" + rsDos.getString("MMGR_MXU") + " " + rsDos.getString("MMGR_MXUF") + ")";

                    Element min = UtilXML.addNode(geriatric, "Line", "Minimum Daily: " + sMin);
                    Element max = UtilXML.addNode(geriatric, "Line", "Maximum Daily: " + sMax);
                }
                rsDos.close();

                // insert pediatric dosage info
                Properties pDos = new Properties();
                sql = "SELECT PDM_UNIT, PDM_UNDESC FROM RPDMUND0";
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    pDos.setProperty(rsDos.getString("PDM_UNIT"), rsDos.getString("PDM_UNDESC"));
                }
                rsDos.close();


                sql = "SELECT "
                    + "MNAGE.PDM_AGEDSC AS MNAGE, MXAGE.PDM_AGEDSC AS MXAGE, "
                    + "PDM_MND, PDM_MNDU, PDM_MNU, PDM_MNUF, "
                    + "PDM_MXD, PDM_MXDU, PDM_MXU, PDM_MXUF, "
                    + "PDM_NTED, PDM_NTEDU, PDM_NTEU, PDM_NTEUF "
                    + "FROM RPDMMA0, RPDMWT1 AS MNAGE, RPDMWT1 AS MXAGE "
                    + "WHERE (RPDMMA0.PDM_MNAGE BETWEEN MNAGE.PDM_MNAGE AND MNAGE.PDM_MXAGE) "
                    + "AND (RPDMMA0.PDM_MXAGE BETWEEN MXAGE.PDM_MXAGE AND MXAGE.PDM_MXAGE) "
                    + "AND (PDM_MND < 999999) "
                    + "AND (GCN_SEQNO = 8346)";
                rsDos = db.GetSQL(sql);
                while(rsDos.next())
                {
                    String sTxt = rsDos.getString("MNAGE") + " to " + rsDos.getString("MXAGE");
                    Element head = UtilXML.addNode(pediatric, "Header");
                    head.setAttribute("text", sTxt);

                    if(pDos.getProperty(rsDos.getString("PDM_MNDU"), "").length()>0)
                    {
                        sTxt = "Minimum: " + rsDos.getString("PDM_MND") + " " + pDos.getProperty(rsDos.getString("PDM_MNDU"), "");
                        if(pDos.getProperty(rsDos.getString("PDM_MNUF"), "").length()>0)
                        {
                            sTxt += " (" + rsDos.getString("PDM_MNU") + " " + pDos.getProperty(rsDos.getString("PDM_MNUF"), "") + ")";
                        }
                        UtilXML.addNode(head, "Line", sTxt);
                    }

                    if(pDos.getProperty(rsDos.getString("PDM_MXDU"), "").length()>0)
                    {
                        sTxt = "Maximum: " + rsDos.getString("PDM_MXD") + " " + pDos.getProperty(rsDos.getString("PDM_MXDU"), "");
                        if(pDos.getProperty(rsDos.getString("PDM_MXUF"), "").length()>0)
                        {
                            sTxt += " (" + rsDos.getString("PDM_MXU") + " " + pDos.getProperty(rsDos.getString("PDM_MXUF"), "") + ")";
                        }
                        UtilXML.addNode(head, "Line", sTxt);
                    }

                    if(pDos.getProperty(rsDos.getString("PDM_NTEDU"), "").length()>0)
                    {
                        sTxt = "Not to Exceed: " + rsDos.getString("PDM_NTED") + " " + pDos.getProperty(rsDos.getString("PDM_NTEDU"), "");
                        if(pDos.getProperty(rsDos.getString("PDM_NTEUF"), "").length()>0)
                        {
                            sTxt += " (" + rsDos.getString("PDM_NTEU") + " " + pDos.getProperty(rsDos.getString("PDM_NTEUF"), "") + ")";
                        }
                        UtilXML.addNode(head, "Line", sTxt);
                    }
                }
                rsDos.close();

                pDos = null;

                if(! adult.hasChildNodes())
                {
                    dosage.removeChild(adult);
                }
                if(! geriatric.hasChildNodes())
                {
                    dosage.removeChild(geriatric);
                }
                if(! pediatric.hasChildNodes())
                {
                    dosage.removeChild(pediatric);
                }
            }
            rs.close();

            if(gcnList.size()>0)
            {
                String gcnJoin = RxUtil.joinArray(gcnList.toArray());

                Element nod = null;
                int iNod = -1;

                // Add Ingredient Info

                sql = "SELECT DISTINCT RGCNSEQ3.HICL_SEQNO, RHICLSQ1.GNN "
                    + "FROM RGCNSEQ3 "
                    + "INNER JOIN RHICLSQ1 ON RGCNSEQ3.HICL_SEQNO = RHICLSQ1.HICL_SEQNO "
                    + "WHERE GCN_SEQNO IN (" + gcnJoin + ")";
                rs = db.GetSQL(sql);
                while(rs.next())
                {
                    Element hicList = UtilXML.addNode(hicInfo, "IngredientList");
                    hicList.setAttribute("listName", rs.getString("GNN"));

                    sql = "SELECT RHICD3.HIC_ROOT FROM RHICD3 "
                        + "INNER JOIN RHICL1 ON RHICD3.HIC_SEQN = RHICL1.HIC_SEQN "
                        + "WHERE RHICL1.HICL_SEQNO = " + rs.getInt("HICL_SEQNO");
                    ResultSet rsHICL = db.GetSQL(sql);

                    while(rsHICL.next())
                    {
                        sql = "SELECT RHIC4D0.HIC4_DESC, RHIC3D2.HIC3_DESC, "
                            + "RHIC2D2.HIC2_DESC, RHIC1D1.HIC1_DESC "
                            + "FROM RHIC4D0 "
                            + "INNER JOIN RHIC3D2 ON RHIC4D0.HIC4_ROOT = RHIC3D2.HIC3_SEQN "
                            + "INNER JOIN RHIC2D2 ON RHIC3D2.HIC3_ROOT = RHIC2D2.HIC2_SEQN "
                            + "INNER JOIN RHIC1D1 ON RHIC2D2.HIC2_ROOT = RHIC1D1.HIC1_SEQN "
                            + "WHERE RHIC4D0.HIC4_SEQN = " + rsHICL.getInt("HIC_ROOT") + " "
                            + "ORDER BY RHIC4D0.HIC4_DESC";
                        ResultSet rsHIC = db.GetSQL(sql);
                        while(rsHIC.next())
                        {
                            Element hic = UtilXML.addNode(hicList, "Ingredient");
                            hic.setAttribute("ingredientName", rsHIC.getString("HIC4_DESC"));

                            UtilXML.addNode(hic, "PharmacologicalClass", rsHIC.getString("HIC3_DESC"));
                            UtilXML.addNode(hic, "TherapeuticClass", rsHIC.getString("HIC2_DESC"));
                            UtilXML.addNode(hic, "OrganSystem", rsHIC.getString("HIC1_DESC"));
                        }
                        rsHIC.close();
                    }
                    rsHICL.close();
                }
                rs.close();

                // Add DDI Info

                sql = "SELECT DISTINCT RADIMMA5.DDI_DES, RADIMMA5.DDI_SL, RADIMMA5.DDI_MONOX "
                    + "FROM RADIMMA5 INNER JOIN RADIMGC4 "
                    + "ON RADIMMA5.DDI_CODEX = RADIMGC4.DDI_CODEX "
                    + "WHERE RADIMGC4.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY RADIMMA5.DDI_DES";
                rs = db.GetSQL(sql);
                while(rs.next())
                {
                    Element ddi = UtilXML.addNode(ddiInfo, "Interaction");
                    ddi.setAttribute("description", rs.getString("DDI_DES"));
                    ddi.setAttribute("severity", String.valueOf(rs.getInt("DDI_SL")));
                    ddi.setAttribute("monox", String.valueOf(rs.getInt("DDI_MONOX")));

                    sql = "SELECT IAMTEXTN FROM RADIMMO5 "
                    + "WHERE DDI_MONOX = " + rs.getInt("DDI_MONOX") + " "
                    + "ORDER BY ADI_MONOSN";

                    ResultSet rsLine = db.GetSQL(sql);

                    while(rsLine.next())
                    {
                        Element line = UtilXML.addNode(ddi, "Line", rsLine.getString("IAMTEXTN"));
                        line.setAttribute("number", String.valueOf(rsLine.getRow()));
                    }
                    rsLine.close();
                }
                rs.close();

                // Add DAM Info
                sql = "DROP TABLE IF EXISTS tmpDAM";
                db.RunSQL(sql);

                sql = "CREATE TEMPORARY TABLE tmpDAM TYPE = HEAP "
                    + "SELECT DISTINCT RGCNSEQ3.HICL_SEQNO, RHICL1.HIC_SEQN, "
                    + "RDAMMA2.DAM_AGCSP, RDAMMA2.DAM_AGCCS "
                    + "FROM RGCNSEQ3 LEFT JOIN RHICL1 ON RGCNSEQ3.HICL_SEQNO = RHICL1.HICL_SEQNO "
                    + "LEFT JOIN RDAMMA2 ON RHICL1.HIC_SEQN = RDAMMA2.HIC_SEQN "
                    + "WHERE RGCNSEQ3.GCN_SEQNO IN (" + gcnJoin + ")";
                db.RunSQL(sql);

                sql = "SELECT DISTINCT TYPECODE, DESCRIPTION FROM CDAMPICK C, tmpDAM D "
                    + "WHERE C.HICL_SEQNO = D.HICL_SEQNO "
                    + "OR C.HIC_SEQNO = D.HIC_SEQN "
                    + "OR C.AGCSP = D.DAM_AGCSP "
                    + "OR C.AGCCS = D.DAM_AGCCS "
                    + "ORDER BY TYPECODE DESC, DESCRIPTION";
                rs = db.GetSQL(sql);
                nod = null;
                while(rs.next())
                {
                    String sNod = "";

                    switch(rs.getInt("TYPECODE"))
                    {
                        case 5:
                            sNod = "CrossSensitive";
                            break;
                        case 4:
                            sNod = "AllergyGroups";
                            break;
                        case 3:
                            sNod = "IngredientLists";
                            break;
                        case 2:
                            sNod = "GenericNames";
                            break;
                        case 1:
                            sNod = "BrandNames";
                            break;
                    }

                    if(sNod.length()>0)
                    {
                        UtilXML.addNode(damInfo, sNod, rs.getString("DESCRIPTION"));
                    }
                }
                rs.close();

                // Add Disease Info

                // Indications
                sql = "SELECT DISTINCT RINDMMA1.INDCTS_DSC, RINDMMA1.INDCTS_LBL, RINDMMA1.FDBDX "
                    + "FROM RINDMGC0 INNER JOIN RINDMMA1 ON RINDMGC0.INDCTS = RINDMMA1.INDCTS "
                    + "WHERE RINDMGC0.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY RINDMMA1.INDCTS_DSC, RINDMMA1.INDCTS_SN";
                rs = db.GetSQL(sql);
                while(rs.next())
                {
                    nod = UtilXML.addNode(disInfo, "Indication");
                    nod.setAttribute("description", rs.getString("INDCTS_DSC"));
                    if(rs.getString("INDCTS_LBL").equals("L"))
                    {
                        s = "Yes";
                    }
                    else
                    {
                        s = "No";
                    }
                    nod.setAttribute("labeled", s);
                    nod.setAttribute("fdbdx", rs.getString("FDBDX"));
                }
                rs.close();

                // Contraindications
                sql = "SELECT DISTINCT RDDCMMA0.DDXCN_DESC, RDDCMMA0.DDXCN_SL, RDDCMMA0.FDBDX "
                    + "FROM RDDCMGC0 INNER JOIN RDDCMMA0 ON RDDCMGC0.DDXCN = RDDCMMA0.DDXCN "
                    + "WHERE RDDCMGC0.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY RDDCMMA0.DDXCN_DESC, RDDCMMA0.DDXCN_SL";
                rs = db.GetSQL(sql);
                while(rs.next())
                {
                    nod = UtilXML.addNode(disInfo, "Contraindication");
                    nod.setAttribute("description", rs.getString("DDXCN_DESC"));

                    switch(rs.getInt("DDXCN_SL"))
                    {
                        case 1:
                            s = "High";
                            break;
                        case 2:
                            s = "Medium";
                            break;
                        default:
                            s = "Low";
                    }
                    nod.setAttribute("severity", s);
                    nod.setAttribute("fdbdx", rs.getString("FDBDX"));
                }
                rs.close();

                // Side Effects
                sql = "SELECT DISTINCT RSIDEMA2.SIDE_DDESC, RSIDEMA2.SIDE_MDESC, "
                    + "RSIDEMA2.SIDE_FREQ, RSIDEMA2.SIDE_SEV, RSIDEMA2.SIDE_VISCD, "
                    + "RSIDEMA2.SIDE_LABCD, RSIDEMA2.SIDE_PHYS, RSIDEMA2.SIDE_HYPER, "
                    + "RSIDEMA2.FDBDX "
                    + "FROM RSIDEGC0 INNER JOIN RSIDEMA2 ON RSIDEGC0.SIDE = RSIDEMA2.SIDE "
                    + "WHERE RSIDEGC0.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY RSIDEMA2.SIDE_DDESC, RSIDEMA2.SIDE_MDESC";
                rs = db.GetSQL(sql);
                while(rs.next())
                {
                    nod = UtilXML.addNode(disInfo, "SideEffect");
                    nod.setAttribute("description",
                        rs.getString("SIDE_DDESC") + "/" + rs.getString("SIDE_MDESC"));

                    switch (rs.getInt("SIDE_FREQ"))
                    {
                        case 0:
                            s = "High";
                            break;
                        case 1:
                            s = "Medium";
                            break;
                        default:
                            s = "Low";
                    }
                    nod.setAttribute("frequency", s);

                    if(rs.getInt("SIDE_SEV")==1)
                    {
                        s = "High";
                    }
                    else
                    {
                        s = "Low";
                    }
                    nod.setAttribute("severity", s);

                    switch (rs.getInt("SIDE_VISCD"))
                    {
                        case 0:
                            s = "Visible";
                            break;
                        case 1:
                            s = "May be visible";
                            break;
                        case 2:
                            s = "Not visible";
                            break;
                        default:
                            s = "";
                    }
                    nod.setAttribute("visibility", s);

                    if(rs.getInt("SIDE_LABCD")==1)
                    {
                        s = "Yes";
                    }
                    else
                    {
                        s = "No";
                    }
                    nod.setAttribute("testRecommended", s);

                    if(rs.getInt("SIDE_PHYS")==1)
                    {
                        s = "Yes";
                    }
                    else
                    {
                        s = "No";
                    }
                    nod.setAttribute("contactPhysician", s);

                    if(rs.getString("SIDE_HYPER").equalsIgnoreCase("H"))
                    {
                        s = "Yes";
                    }
                    else
                    {
                        s = "No";
                    }
                    nod.setAttribute("hypersensitivity", s);

                    nod.setAttribute("fdbdx", rs.getString("FDBDX"));
                }
                rs.close();

                // Add PEM Info

                sql = "SELECT DISTINCT RPEMMOE2.PEMONO, RPEMMOE2.PEMONOE_SN, "
                    + "RPEMMOE2.PEMTXTE "
                    + "FROM RPEMMOE2 INNER JOIN RPEMOGC0 ON RPEMMOE2.PEMONO = RPEMOGC0.PEMONO "
                    + "WHERE RPEMOGC0.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY PEMONO, PEMONOE_SN";
                rs = db.GetSQL(sql);
                nod = null;
                iNod = -1;
                while(rs.next())
                {
                    if(rs.getInt("PEMONO")!=iNod)
                    {
                        iNod = rs.getInt("PEMONO");

                        nod = UtilXML.addNode(pemInfo, "Monograph");
                        nod.setAttribute("pemono", String.valueOf(iNod));

                        sql = "SELECT DGNAME FROM RPEMMA4 WHERE PEMONO = " + iNod;
                        ResultSet rsName = db.GetSQL(sql);
                        if(rsName.next())
                        {
                            nod.setAttribute("description", rsName.getString("DGNAME"));
                        }
                        rsName.close();
                    }

                    UtilXML.addNode(nod, "Line", rs.getString("PEMTXTE"))
                        .setAttribute("number", String.valueOf(rs.getInt("PEMONOE_SN")));
                }
                rs.close();

                // Add FOOD Info

                sql = "SELECT DISTINCT RDFIMMO0.FDCDE, FDCDE_SN, FDTXT "
                    + "FROM RDFIMMO0 INNER JOIN RDFIMGC0 ON RDFIMMO0.FDCDE = RDFIMGC0.FDCDE "
                    + "WHERE RDFIMGC0.GCN_SEQNO IN (" + gcnJoin + ") "
                    + "ORDER BY FDCDE, FDCDE_SN";
                rs = db.GetSQL(sql);
                nod = null;
                iNod = -1;
                while(rs.next())
                {
                    if(rs.getInt("FDCDE")!=iNod)
                    {
                        iNod = rs.getInt("FDCDE");

                        nod = UtilXML.addNode(dfimInfo, "Monograph");
                        nod.setAttribute("fdcde", String.valueOf(iNod));

                        sql = "SELECT DNAME FROM RDFIMMA0 WHERE FDCDE = " + iNod;
                        ResultSet rsName = db.GetSQL(sql);
                        if(rsName.next())
                        {
                            nod.setAttribute("description", rsName.getString("DNAME"));
                        }
                        rsName.close();
                    }

                    UtilXML.addNode(nod, "Line", rs.getString("FDTXT"))
                        .setAttribute("number", String.valueOf(rs.getInt("FDCDE_SN")));
                }
                rs.close();
            }

            db.CloseConn();

            return UtilXML.toXML(doc);
        }
        catch (SQLException e)
        {
            e.printStackTrace(System.out);
            throw e;
        }
    }
}
