package oscar.oscarRx.data;

import oscar.oscarDB.*;
import java.util.*;
import java.sql.*;

public class RxCodesData
{
    public Disease getDisease(String ICD9)
    {
        return new Disease(ICD9);
    }

    public FrequencyCode[] getFrequencyCodes()
    {
        FrequencyCode[] arr = {};
        ArrayList lst = new ArrayList();

        try
        {
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM ctl_frequency";

            rs = db.GetSQL(sql);

            while (rs.next())
            {
                lst.add(new FrequencyCode(rs.getInt("freqid"), rs.getString("freqcode"), rs.getInt("dailymin"), rs.getInt("dailymax")));
            }

            rs.close();
            db.CloseConn();

            arr = (FrequencyCode[])lst.toArray(arr);

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public String[] getSpecialInstructions()
    {
        String[] arr = {};
        ArrayList lst = new ArrayList();

        try
        {
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM ctl_specialinstructions";

            rs = db.GetSQL(sql);

            while (rs.next())
            {
                lst.add(rs.getString("description"));
            }

            rs.close();
            db.CloseConn();

            arr = (String[])lst.toArray(arr);
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public class Disease
    {
        String ICD9;
        String diseaseName;

        public Disease(String ICD9)
        {
            this.ICD9 = ICD9;
        }

        public String getICD9()
        {
            return this.ICD9;
        }

        public String getDiseaseName()
        {
            if(this.diseaseName==null)
            {
                try
                {
                    DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                    ResultSet rs;

                    rs = db.GetSQL("SELECT FDBDX_DESC FROM RFDBDX1 INNER JOIN RICD92 "
                        + "ON RFDBDX1.FDBDX = RICD92.FDBDX WHERE ICD9_E = '" + this.ICD9 + "'");

                    if(rs.next())
                    {
                        this.diseaseName = rs.getString("FDBDX_DESC");
                    }

                    rs.close();
                    db.CloseConn();
                } catch (SQLException e)
                {
                    System.out.println(e.getMessage());
                }
            }

            return this.diseaseName;
        }
    }

    public class FrequencyCode
    {
        int freqId;
        String freqCode;
        int dailyMin;
        int dailyMax;

        public FrequencyCode(int freqId, String freqCode, int dailyMin, int dailyMax)
        {
            this.freqId=freqId;
            this.freqCode=freqCode;
            this.dailyMin=dailyMin;
            this.dailyMax=dailyMax;
        }

        public int getFreqId()
        {
            return this.freqId;
        }

        public String getFreqCode()
        {
            return this.freqCode;
        }

        public int getDailyMin()
        {
            return this.dailyMin;
        }

        public int getDailyMax()
        {
            return this.dailyMax;
        }
    }
}