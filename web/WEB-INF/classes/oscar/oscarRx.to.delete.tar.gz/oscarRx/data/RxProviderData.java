package oscar.oscarRx.data;

import oscar.oscarDB.*;

import java.util.*;
import java.sql.*;

public class RxProviderData
{
    public Provider getProvider(String providerNo)
    {
        Provider provider = null;

        try
        {
            //Get Provider from database
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM provider WHERE provider_no = '" + providerNo + "'";

            rs = db.GetSQL(sql);

            if (rs.next())
            {
                String surname = rs.getString("last_name");
                String firstName = rs.getString("first_name");
                if(firstName.indexOf("Dr.")<0)
                {
                    firstName = "Dr. " + firstName;
                }
                String clinicName = "Stonechurch Family Health Centre";
                String clinicAddress = "549 Stone Church Rd. E.";
                String clinicCity = "Hamilton";
                String clinicPostal = "L8W 3L2";
                String clinicPhone = "905-575-1300";
                String clinicFax = "905-575-0779";


                provider = new Provider(
                    providerNo, surname, firstName, clinicName, clinicAddress,
                    clinicCity, clinicPostal, clinicPhone, clinicFax);
            }

            rs.close();
            db.CloseConn();
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return provider;
    }

    public class Provider
    {
        String providerNo;
        String surname;
        String firstName;
        String clinicName;
        String clinicAddress;
        String clinicCity;
        String clinicPostal;
        String clinicPhone;
        String clinicFax;

        public Provider(String providerNo, String surname, String firstName,
        String clinicName, String clinicAddress, String clinicCity,
        String clinicPostal, String clinicPhone, String clinicFax)
        {
            this.providerNo = providerNo;
            this.surname = surname;
            this.firstName = firstName;
            this.clinicName = clinicName;
            this.clinicAddress = clinicAddress;
            this.clinicCity = clinicCity;
            this.clinicPostal = clinicPostal;
            this.clinicPhone = clinicPhone;
            this.clinicFax = clinicFax;
        }

        public String getProviderNo()
        {
            return this.providerNo;
        }

        public String getSurname()
        {
            return this.surname;
        }

        public String getFirstName()
        {
            return this.firstName;
        }

        public String getClinicName()
        {
            return this.clinicName;
        }

        public String getClinicAddress()
        {
            return this.clinicAddress;
        }

        public String getClinicCity()
        {
            return this.clinicCity;
        }

        public String getClinicPostal()
        {
            return this.clinicPostal;
        }

        public String getClinicPhone()
        {
            return this.clinicPhone;
        }

        public String getClinicFax()
        {
            return this.clinicFax;
        }
    }
}
