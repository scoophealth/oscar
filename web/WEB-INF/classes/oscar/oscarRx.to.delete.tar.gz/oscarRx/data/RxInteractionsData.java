package oscar.oscarRx.data;

import oscar.oscarDB.*;
import oscar.oscarRx.util.*;
import java.util.*;
import java.sql.*;

public class RxInteractionsData
{
    public DrugDrugInteraction[] getDDI(Integer[] GCN_SEQNO)
    {
        DrugDrugInteraction[] retArray = {};

        if(GCN_SEQNO.length>0)
        {
            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;
                ResultSet rs2;
                String sql;
                String s;

                ArrayList lst = new ArrayList();
                DrugDrugInteraction DDI;

                // drop temporary tables if they still exist
                sql = "DROP TABLE IF EXISTS tmpDDI1";
                db.RunSQL(sql);
                sql = "DROP TABLE IF EXISTS tmpDDI2";
                db.RunSQL(sql);
                sql = "DROP TABLE IF EXISTS tmpDDI3";
                db.RunSQL(sql);

                // get all our codexes into tmpDDI1
                sql = "CREATE TEMPORARY TABLE tmpDDI1 TYPE = HEAP "
                    + "SELECT GCN_SEQNO, DDI_CODEX "
                    + "FROM RADIMGC4 WHERE GCN_SEQNO IN ("
                    + RxUtil.joinArray(GCN_SEQNO) + ")";
                db.RunSQL(sql);

                // copy temp table 1 to temp table 2
                sql = "CREATE TEMPORARY TABLE tmpDDI2 TYPE = HEAP "
                    + "SELECT * FROM tmpDDI1";
                db.RunSQL(sql);

                // put the codexes that add up to 32000 into our third temp table
                sql = "CREATE TEMPORARY TABLE tmpDDI3 TYPE = HEAP "
                    + "SELECT t1.DDI_CODEX FROM tmpDDI1 t1, tmpDDI2 t2 "
                    + "WHERE t1.GCN_SEQNO <> t2.GCN_SEQNO "
                    + "AND t1.DDI_CODEX + t2.DDI_CODEX = 32000";
                db.RunSQL(sql);

                // get the monox and descriptions for each codex
                sql = "SELECT RADIMMA5.DDI_MONOX, MIN(RADIMMA5.DDI_DES) AS Descr, "
                    + "RADIMMA5.DDI_SL "
                    + "FROM RADIMMA5 INNER JOIN tmpDDI3 "
                    + "ON RADIMMA5.DDI_CODEX = tmpDDI3.DDI_CODEX "
                    + "GROUP BY RADIMMA5.DDI_MONOX "
                    + "ORDER BY Descr";
                rs = db.GetSQL(sql);

                // create the interactions
                while(rs.next())
                {
                    sql = "SELECT RADIMSL1.DDI_SLTXT "
                        + "FROM RADIMSL1 WHERE DDI_SL = " + rs.getString("DDI_SL") + " "
                        + "ORDER BY DDI_SLSN";
                    rs2 = db.GetSQL(sql);

                    s = rs.getString("DDI_SL") + " - ";
                    while(rs2.next())
                    {
                        s += rs2.getString("DDI_SLTXT") + " ";
                    }
                    rs2.close();

                    DDI = new DrugDrugInteraction(rs.getInt("DDI_MONOX"),
                        rs.getString("Descr"), Integer.parseInt(rs.getString("DDI_SL")), s);

                    lst.add(DDI);
                }

                retArray = (DrugDrugInteraction[])lst.toArray(retArray);

                // clean up

                rs.close();

                sql = "DROP TABLE IF EXISTS tmpDDI1";
                db.RunSQL(sql);
                sql = "DROP TABLE IF EXISTS tmpDDI2";
                db.RunSQL(sql);
                sql = "DROP TABLE IF EXISTS tmpDDI3";
                db.RunSQL(sql);


                db.CloseConn();
            }
            catch (SQLException e)
            {
                e.printStackTrace(System.out);
            }
        }

        return retArray;
    }

    public String[] getDDIMonograph(int monox)
    {
        String[] arr = {};
        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;
            String sql;

            sql = "SELECT IAMTEXTN FROM RADIMMO5 "
            + "WHERE DDI_MONOX = " + monox + " "
            + "ORDER BY ADI_MONOSN";

            rs = db.GetSQL(sql);

            ArrayList lst = new ArrayList();

            while(rs.next())
            {
                lst.add(rs.getString("IAMTEXTN"));
            }

            arr = (String[])lst.toArray(arr);

            rs.close();

            db.CloseConn();
        }
        catch (SQLException e)
        {
            e.printStackTrace(System.out);
        }

        return arr;
    }

    public class DrugDrugInteraction
    {
        private int monox;
        private String desc;
        private String severity;
        private int severityLevel;

        public DrugDrugInteraction(int monox, String desc, int severityLevel, String severity)
        {
            this.monox = monox;
            this.desc = desc;
            this.severityLevel = severityLevel;
            this.severity = severity;
        }
        public int getMonox()
        {
            return monox;
        }
        public String getDesc()
        {
            return desc;
        }
        public int getSeverityLevel()
        {
            return this.severityLevel;
        }
        public String getSeverity()
        {
            return this.severity;
        }
    }
}