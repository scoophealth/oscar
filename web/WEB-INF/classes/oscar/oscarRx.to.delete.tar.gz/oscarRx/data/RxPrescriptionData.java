package oscar.oscarRx.data;

import oscar.oscarDB.*;
import oscar.oscarRx.util.*;

import java.util.*;
import java.sql.*;

public class RxPrescriptionData
{
    public Prescription getPrescription(int drugId)
    {
        Prescription prescription = null;

        try
        {
            //Get Prescription from database
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM drugs WHERE archived = 0 AND drugid = " + drugId;

            rs = db.GetSQL(sql);

            if (rs.next())
            {
                prescription = new Prescription(drugId,
                    rs.getString("provider_no"), rs.getInt("demographic_no"));
                prescription.setRxDate(rs.getDate("rx_date"));
                prescription.setEndDate(rs.getDate("end_date"));
                prescription.setBrandName(rs.getString("BN"));
                prescription.setGCN_SEQNO(rs.getInt("GCN_SEQNO"));
                prescription.setCustomName(rs.getString("customName"));
                prescription.setTakeMin(rs.getFloat("takemin"));
                prescription.setTakeMax(rs.getFloat("takemax"));
                prescription.setFrequencyCode(rs.getString("freqcode"));
                prescription.setDuration(rs.getString("duration"));
                prescription.setDurationUnit(rs.getString("durunit"));
                prescription.setQuantity(rs.getString("quantity"));
                prescription.setRepeat(rs.getInt("repeat"));
                prescription.setNosubs(rs.getInt("nosubs"));
                prescription.setPrn(rs.getInt("prn"));
                prescription.setSpecial(rs.getString("special"));
            }

            rs.close();
            db.CloseConn();
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return prescription;
    }

    public Prescription newPrescription(String providerNo, int demographicNo)
    {
        //Create new prescription (only in memory)
        return new Prescription(0, providerNo, demographicNo);
    }

    public Prescription newPrescription(String providerNo, int demographicNo, Favorite favorite)
    {
        //Create new prescription from favorite (only in memory)
        Prescription prescription = new Prescription(0, providerNo, demographicNo);

        prescription.setRxDate(RxUtil.Today());
        prescription.setEndDate(null);
        prescription.setBrandName(favorite.getBN());
        prescription.setGCN_SEQNO(favorite.getGCN_SEQNO());
        prescription.setCustomName(favorite.getCustomName());
        prescription.setTakeMin(favorite.getTakeMin());
        prescription.setTakeMax(favorite.getTakeMax());
        prescription.setFrequencyCode(favorite.getFrequencyCode());
        prescription.setDuration(favorite.getDuration());
        prescription.setDurationUnit(favorite.getDurationUnit());
        prescription.setQuantity(favorite.getQuantity());
        prescription.setRepeat(favorite.getRepeat());
        prescription.setNosubs(favorite.getNosubs());
        prescription.setPrn(favorite.getPrn());
        prescription.setSpecial(favorite.getSpecial());

        return prescription;
    }

    public Prescription newPrescription(String providerNo, int demographicNo, Prescription rePrescribe)
    {
        //Create new prescription
        Prescription prescription = new Prescription(0, providerNo, demographicNo);

        prescription.setRxDate(RxUtil.Today());
        prescription.setEndDate(null);
        prescription.setBrandName(rePrescribe.getBrandName());
        prescription.setGCN_SEQNO(rePrescribe.getGCN_SEQNO());
        prescription.setCustomName(rePrescribe.getCustomName());
        prescription.setTakeMin(rePrescribe.getTakeMin());
        prescription.setTakeMax(rePrescribe.getTakeMax());
        prescription.setFrequencyCode(rePrescribe.getFrequencyCode());
        prescription.setDuration(rePrescribe.getDuration());
        prescription.setDurationUnit(rePrescribe.getDurationUnit());
        prescription.setQuantity(rePrescribe.getQuantity());
        prescription.setRepeat(rePrescribe.getRepeat());
        prescription.setNosubs(rePrescribe.getNosubs());
        prescription.setPrn(rePrescribe.getPrn());
        prescription.setSpecial(rePrescribe.getSpecial());

        return prescription;
    }

    public Prescription[] getPrescriptionsByPatient(int demographicNo)
    {
        Prescription[] arr = {};
        ArrayList lst = new ArrayList();

        try
        {
            //Get Prescription from database
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM drugs WHERE archived = 0 AND "
                        + "demographic_no = " + demographicNo + " "
                        + "ORDER BY rx_date DESC, drugId DESC";

            Prescription p;

            rs = db.GetSQL(sql);

            while(rs.next())
            {
                p = new Prescription(rs.getInt("drugid"), rs.getString("provider_no"), demographicNo);
                p.setRxDate(rs.getDate("rx_date"));
                p.setEndDate(rs.getDate("end_date"));
                p.setBrandName(rs.getString("BN"));
                p.setGCN_SEQNO(rs.getInt("GCN_SEQNO"));
                p.setCustomName(rs.getString("customName"));
                p.setTakeMin(rs.getFloat("takemin"));
                p.setTakeMax(rs.getFloat("takemax"));
                p.setFrequencyCode(rs.getString("freqcode"));
                p.setDuration(rs.getString("duration"));
                p.setDurationUnit(rs.getString("durunit"));
                p.setQuantity(rs.getString("quantity"));
                p.setRepeat(rs.getInt("repeat"));
                p.setNosubs(rs.getInt("nosubs"));
                p.setPrn(rs.getInt("prn"));
                p.setSpecial(rs.getString("special"));

                lst.add(p);
            }

            rs.close();
            db.CloseConn();

            arr = (Prescription[])lst.toArray(arr);

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public Prescription[] getUniquePrescriptionsByPatient(int demographicNo)
    {
        Prescription[] arr = {};
        ArrayList lst = new ArrayList();

        try
        {
            //Get Prescription from database
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM drugs WHERE archived = 0 AND "
                        + "demographic_no = " + demographicNo + " "
                        + "ORDER BY rx_date DESC, drugId DESC";

            Prescription p;

            rs = db.GetSQL(sql);

            while(rs.next())
            {
                boolean b = true;

                for (int i=0; i < lst.size(); i++)
                {
                    Prescription p2 = (Prescription)lst.get(i);

                    if(p2.getGCN_SEQNO() == rs.getInt("GCN_SEQNO"))
                    {
                        if(p2.getGCN_SEQNO() != 0) // not custom - safe GCN
                        {
                            b = false;
                        }
                        else // custom
                        {
                            if(p2.getCustomName() != null && rs.getString("customName") != null)
                            {
                                if(p2.getCustomName().equals(rs.getString("customName"))) // same custom
                                {
                                    b = false;
                                }
                            }
                        }
                    }
                }

                if(b)
                {
                    p = new Prescription(rs.getInt("drugid"), rs.getString("provider_no"), demographicNo);
                    p.setRxDate(rs.getDate("rx_date"));
                    p.setEndDate(rs.getDate("end_date"));
                    p.setBrandName(rs.getString("BN"));
                    p.setGCN_SEQNO(rs.getInt("GCN_SEQNO"));
                    p.setCustomName(rs.getString("customName"));
                    p.setTakeMin(rs.getFloat("takemin"));
                    p.setTakeMax(rs.getFloat("takemax"));
                    p.setFrequencyCode(rs.getString("freqcode"));
                    p.setDuration(rs.getString("duration"));
                    p.setDurationUnit(rs.getString("durunit"));
                    p.setQuantity(rs.getString("quantity"));
                    p.setRepeat(rs.getInt("repeat"));
                    p.setNosubs(rs.getInt("nosubs"));
                    p.setPrn(rs.getInt("prn"));
                    p.setSpecial(rs.getString("special"));

                    lst.add(p);
                }
            }

            rs.close();
            db.CloseConn();

            arr = (Prescription[])lst.toArray(arr);

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public Prescription[] getSimilarPrescriptions(int demographicNo, int GCN_SEQNO, String customName)
    {
        Prescription[] arr = {};
        ArrayList lst = new ArrayList();

        try
        {
            //Get Prescription from database
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            String sql;
            if(GCN_SEQNO!=0)
            {
                sql = "SELECT * FROM drugs WHERE archived = 0 AND "
                    + "demographic_no = " + demographicNo + " AND "
                    + "GCN_SEQNO = " + GCN_SEQNO + " "
                    + "ORDER BY rx_date DESC, drugId DESC";
            }
            else
            {
                sql = "SELECT * FROM drugs WHERE archived = 0 AND "
                    + "demographic_no = " + demographicNo + " AND "
                    + "GCN_SEQNO = 0 AND customName = '" + customName + "' "
                    + "ORDER BY rx_date DESC, drugId DESC";
            }

            Prescription p;

            rs = db.GetSQL(sql);

            while(rs.next())
            {
                p = new Prescription(rs.getInt("drugid"), rs.getString("provider_no"), demographicNo);
                p.setRxDate(rs.getDate("rx_date"));
                p.setEndDate(rs.getDate("end_date"));
                p.setBrandName(rs.getString("BN"));
                p.setGCN_SEQNO(rs.getInt("GCN_SEQNO"));
                p.setCustomName(rs.getString("customName"));
                p.setTakeMin(rs.getFloat("takemin"));
                p.setTakeMax(rs.getFloat("takemax"));
                p.setFrequencyCode(rs.getString("freqcode"));
                p.setDuration(rs.getString("duration"));
                p.setDurationUnit(rs.getString("durunit"));
                p.setQuantity(rs.getString("quantity"));
                p.setRepeat(rs.getInt("repeat"));
                p.setNosubs(rs.getInt("nosubs"));
                p.setPrn(rs.getInt("prn"));
                p.setSpecial(rs.getString("special"));

                lst.add(p);
            }

            rs.close();
            db.CloseConn();

            arr = (Prescription[])lst.toArray(arr);

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return arr;
    }

    public Favorite[] getFavorites(String providerNo)
    {
        Favorite[] arr = {};
        LinkedList lst = new LinkedList();

	try
	{
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;
            Favorite favorite;

            rs = db.GetSQL("SELECT * FROM favorites WHERE provider_no = '"
                    + providerNo + "' ORDER BY favoritename");

            while(rs.next())
            {
                favorite = new Favorite(rs.getInt("favoriteid"), rs.getString("provider_no"),
                    rs.getString("favoritename"),
                    rs.getString("BN"), rs.getInt("GCN_SEQNO"), rs.getString("customName"),
                    rs.getFloat("takemin"), rs.getFloat("takemax"), rs.getString("freqcode"),
                    rs.getString("duration"), rs.getString("durunit"),
                    rs.getString("quantity"),
                    rs.getInt("repeat"), rs.getInt("nosubs"),
                    rs.getInt("prn"), rs.getString("special"));

                lst.add(favorite);
            }

            rs.close();
            db.CloseConn();

            arr = (Favorite[])lst.toArray(arr);

	} catch (SQLException e)
	{
            System.out.println(e.getMessage());
	}

	return arr;
    }

    public Favorite getFavorite(int favoriteId)
    {
        Favorite favorite = null;

        try
        {
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            ResultSet rs;

            rs = db.GetSQL("SELECT * FROM favorites WHERE favoriteid = " + favoriteId);

            if(rs.next())
            {
                favorite = new Favorite(rs.getInt("favoriteid"), rs.getString("provider_no"),
                    rs.getString("favoritename"),
                    rs.getString("BN"), rs.getInt("GCN_SEQNO"), rs.getString("customName"),
                    rs.getFloat("takemin"), rs.getFloat("takemax"), rs.getString("freqcode"),
                    rs.getString("duration"), rs.getString("durunit"),
                    rs.getString("quantity"),
                    rs.getInt("repeat"), rs.getInt("nosubs"),
                    rs.getInt("prn"), rs.getString("special"));
            }

            rs.close();
            db.CloseConn();
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return favorite;
    }

    public boolean deleteFavorite(int favoriteId)
    {
        boolean ret = false;

        try
        {
            DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
            String sql = "DELETE FROM favorites WHERE favoriteid = " + favoriteId;

            db.RunSQL(sql);

            ret = true;
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return ret;
    }

    public class Prescription
    {
        int drugId;
        String providerNo;
        int demographicNo;
        java.util.Date rxDate = null;
        java.util.Date endDate = null;

        String BN = null;       //regular
        int GCN_SEQNO = 0;      //regular

        String customName = null;   //custom

        float takeMin = 0;
        float takeMax = 0;
        String frequencyCode = null;
        String duration = null;
        String durationUnit = null;
        String quantity = null;
        int repeat = 0;
        boolean nosubs = false;
        boolean prn = false;
        String special = null;

        RxDrugData.GCN gcn = null;

        public Prescription(int drugId, String providerNo, int demographicNo)
        {
            this.drugId = drugId;
            this.providerNo = providerNo;
            this.demographicNo = demographicNo;
        }

        public int getDrugId()
        {
            return this.drugId;
        }

        public String getProviderNo()
        {
            return this.providerNo;
        }

        public int getDemographicNo()
        {
            return this.demographicNo;
        }

        public java.util.Date getRxDate()
        {
            return this.rxDate;
        }

        public void setRxDate(java.util.Date RHS)
        {
            this.rxDate = RHS;
        }

        public java.util.Date getEndDate()
        {
            return this.endDate;
        }

        public void setEndDate(java.util.Date RHS)
        {
            this.endDate = RHS;
        }

        public boolean isCurrent()
        {
            boolean b = false;

            try
            {
                GregorianCalendar cal = new GregorianCalendar(Locale.CANADA);
                cal.add(GregorianCalendar.DATE, -1);

                if (this.getEndDate().after(cal.getTime()))
                {
                    b = true;
                }
            } catch (Exception e)
            {
                b = false;
            }

            return b;
        }

        public void calcEndDate()
        {
            GregorianCalendar cal = new GregorianCalendar(Locale.CANADA);
            int days = 0;

            cal.setTime(this.getRxDate());

            if (this.getDuration().length() > 0)
            {
                if (Integer.parseInt(this.getDuration()) > 0)
                {
                    int i = Integer.parseInt(this.getDuration());

                    if (this.getDurationUnit().equals("D"))
                    {
                        days = i;
                    }
                    if (this.getDurationUnit().equals("W"))
                    {
                        days = i * 7;
                    }
                    if (this.getDurationUnit().equals("M"))
                    {
                        days = i * 30;
                    }

                    if (this.getRepeat() > 0)
                    {
                        int r = this.getRepeat();

                        r++;    // if we have a repeat of 1, multiply days by 2

                        days = days * r;
                    }

                    if (days > 0)
                    {
                        cal.add(GregorianCalendar.DATE, days);
                    }
                }
            }

            this.endDate = cal.getTime();
        }

        public String getBrandName()
        {
            return this.BN;
        }

        public void setBrandName(String RHS)
        {
            this.BN = RHS;
            this.gcn=null;
        }

        public int getGCN_SEQNO()
        {
            return this.GCN_SEQNO;
        }

        public void setGCN_SEQNO(int RHS)
        {
            this.GCN_SEQNO = RHS;
            this.gcn=null;
        }

        public RxDrugData.GCN getGCN()
        {
            if (this.gcn==null)
            {
                this.gcn = new RxDrugData().getGCN(this.BN, this.GCN_SEQNO);
            }

            return gcn;
        }

        public boolean isCustom()
        {
            boolean b = false;

            if(this.customName != null)
            {
                b = true;
            }
            else if(this.GCN_SEQNO == 0)
            {
                b = true;
            }
            return b;
        }

        public String getCustomName()
        {
            return this.customName;
        }
        public void setCustomName(String RHS)
        {
            this.customName = RHS;
            if(this.customName!=null)
            {
                if(this.customName.equalsIgnoreCase("null") || this.customName.equalsIgnoreCase(""))
                {
                    this.customName = null;
                }
            }
        }

        public float getTakeMin()
        {
            return this.takeMin;
        }

        public void setTakeMin(float RHS)
        {
            this.takeMin = RHS;
        }

        public String getTakeMinString()
        {
            return RxUtil.FloatToString(this.takeMin);
        }

        public float getTakeMax()
        {
            return this.takeMax;
        }

        public void setTakeMax(float RHS)
        {
            this.takeMax = RHS;
        }

        public String getTakeMaxString()
        {
            return RxUtil.FloatToString(this.takeMax);
        }

        public String getFrequencyCode()
        {
            return this.frequencyCode;
        }

        public void setFrequencyCode(String RHS)
        {
            this.frequencyCode = RHS;
        }

        public String getDuration()
        {
            return this.duration;
        }

        public void setDuration(String RHS)
        {
            this.duration = RHS;
        }

        public String getDurationUnit()
        {
            return this.durationUnit;
        }

        public void setDurationUnit(String RHS)
        {
            this.durationUnit = RHS;
        }

        public String getQuantity()
        {
            return this.quantity;
        }
        public void setQuantity(String RHS)
        {
            if (RHS==null || RHS.equals("null") || RHS.length()<1)
            {
                this.quantity = "0";
            }
            else
            {
                this.quantity = RHS;
            }
        }

        public int getRepeat()
        {
            return this.repeat;
        }

        public void setRepeat(int RHS)
        {
            this.repeat = RHS;
        }

        public boolean getNosubs()
        {
            return this.nosubs;
        }

        public int getNosubsInt()
        {
            if (this.getNosubs()==true)
            {
                return 1;
            } else
            {
                return 0;
            }
        }

        public void setNosubs(boolean RHS)
        {
            this.nosubs = RHS;
        }

        public void setNosubs(int RHS)
        {
            if(RHS==0)
            {
                this.setNosubs(false);
            } else
            {
                this.setNosubs(true);
            }
        }

        public boolean getPrn()
        {
            return this.prn;
        }

        public int getPrnInt()
        {
            if (this.getPrn()==true)
            {
                return 1;
            } else
            {
                return 0;
            }
        }

        public void setPrn(boolean RHS)
        {
            this.prn = RHS;
        }

        public void setPrn(int RHS)
        {
            if(RHS==0)
            {
                this.setPrn(false);
            } else
            {
                this.setPrn(true);
            }
        }

        public String getSpecial()
        {
            return this.special;
        }

        public void setSpecial(String RHS)
        {
            if(RHS != null)
            {
                if(! RHS.equals("null"))
                {
                    this.special = RHS;
                }
                else
                {
                    this.special = null;
                }
            }
            else
            {
                this.special = null;
            }
        }

        public String getSpecialDisplay()
        {
            String ret = "";

            String s = this.getSpecial();

            if(s!=null)
            {
                if(s.length()>0)
                {
                    ret = "<br>";

                    int i;
                    String[] arr = s.split("\n");

                    for(i=0;i<arr.length; i++)
                    {
                        ret += arr[i].trim();
                        if(i<arr.length-1)
                        {
                            ret += "; ";
                        }
                    }
                }
            }

            return ret;
        }

        public String getRxDisplay()
        {
            try
            {
                String ret;

                if(this.isCustom())
                {
                    if(this.customName != null)
                    {
                        ret = this.customName + " ";
                    }
                    else
                    {
                        ret = "Unknown ";
                    }
                }
                else
                {
                    RxDrugData.GCN gcn = this.getGCN();

                    ret = gcn.getBrandName() + " "
                        + gcn.getStrength() + " "
                        + gcn.getDoseForm() + " "
                        + gcn.getRoute() + " ";
                }

                if(this.getTakeMin() != this.getTakeMax())
                {
                    ret += this.getTakeMinString() + "-" + this.getTakeMaxString();
                } else
                {
                    ret += this.getTakeMinString();
                }

                ret += " " + this.getFrequencyCode();

                ret += " " + this.getDuration() + " ";

                if(this.getDurationUnit().equals("D"))
                {
                    ret += "Day";
                }
                if(this.getDurationUnit().equals("W"))
                {
                    ret += "Week";
                }
                if(this.getDurationUnit().equals("M"))
                {
                    ret += "Month";
                }

                if(Integer.parseInt(this.getDuration()) > 1)
                {
                    ret += "s";
                }

                ret += "  ";

                ret += this.getQuantity();

                ret += " Qty  Repeats: ";

                ret += String.valueOf(this.getRepeat());

                if(this.getNosubs())
                {
                    ret += " No subs ";
                }
                if(this.getPrn())
                {
                    ret += " PRN ";
                }

                return ret;
            } catch (Exception e)
            {
                System.out.println(e.getMessage());

                return null;
            }
        }

        public void Delete()
        {
            try
            {
                DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
                String sql;

                if(this.getDrugId()>0)
                {
                    sql = "UPDATE drugs SET archived = 1 WHERE drugid = " + this.getDrugId();
                    db.RunSQL(sql);
                }

                db.CloseConn();
            }
            catch (Exception e)
            {
                e.printStackTrace(System.out);
            }
        }

        public boolean Save()
        {
            boolean b = false;

            // calculate end date
            this.calcEndDate();

            // clean up fields
            if(this.takeMin > this.takeMax)
            {
                this.takeMax = this.takeMin;
            }

            try
            {
                DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
                ResultSet rs;
                String sql;

                // if drugid = 0 this is an add, else update
                if(this.getDrugId()==0)
                {
                    // check to see if there is an identitical prescription in
                    // the database. If there is we'll return that drugid instead
                    // of adding a new prescription.
                    sql = "SELECT drugid FROM drugs WHERE archived = 0 AND "
                    + "provider_no = '" + this.getProviderNo() + "' AND "
                    + "demographic_no = " + this.getDemographicNo() + " AND "
                    + "rx_date = '" + RxUtil.DateToString(this.getRxDate()) + "' AND "
                    + "end_date = '" + RxUtil.DateToString(this.getEndDate()) + "' AND "
                    + "BN = '" + this.getBrandName() + "' AND "
                    + "GCN_SEQNO = " + this.getGCN_SEQNO() + " AND "
                    + "customName = '" + this.getCustomName() + "' AND "
                    + "takemin = " + this.getTakeMin() + " AND "
                    + "takemax = " + this.getTakeMax() + " AND "
                    + "freqcode = '" + this.getFrequencyCode() + "' AND "
                    + "duration = '" + this.getDuration() + "' AND "
                    + "durunit = '" + this.getDurationUnit() + "' AND "
                    + "quantity = '" + this.getQuantity() + "' AND "
                    + "repeat = " + this.getRepeat() + " AND "
                    + "nosubs = " + this.getNosubsInt() + " AND "
                    + "prn = " + this.getPrnInt() + " AND "
                    + "special = '" + RxUtil.replace(this.getSpecial(), "'", "") + "'";

                    rs = db.GetSQL(sql);

                    if(rs.next())
                    {
                        this.drugId = rs.getInt("drugid");
                    }

                    rs.close();

                    b = true;

                    // if it doesn't already exist add it.
                    if(this.getDrugId() == 0)
                    {
                        sql = "INSERT INTO drugs (provider_no, demographic_no, "
                        + "rx_date, end_date, BN, GCN_SEQNO, customName, "
                        + "takemin, takemax, "
                        + "freqcode, duration, durunit, quantity, "
                        + "repeat, nosubs, prn, special) "
                        + "VALUES ('" + this.getProviderNo() + "', " + this.getDemographicNo() + ", '"
                        + RxUtil.DateToString(this.getRxDate()) + "', '"
                        + RxUtil.DateToString(this.getEndDate()) + "', '"
                        + this.getBrandName() + "', " + this.getGCN_SEQNO()
                        + ", '" + this.getCustomName() + "', "
                        + this.getTakeMin() + ", " + this.getTakeMax() + ", '"
                        + this.getFrequencyCode() + "', '" + this.getDuration() + "', '"
                        + this.getDurationUnit() + "', '" + this.getQuantity() + "', "
                        + this.getRepeat() + ", " + this.getNosubsInt() + ", "
                        + this.getPrnInt() + ", '"
                        + RxUtil.replace(this.getSpecial(), "'", "") + "')";

                        db.RunSQL(sql);

                        // it's added, so get the top (most recent) drugid
                        sql = "SELECT Max(drugid) FROM drugs";

                        rs = db.GetSQL(sql);

                        if (rs.next())
                        {
                            this.drugId = rs.getInt(1);
                        }

                        rs.close();

                        b = true;
                    }

                } else  // update the daterbase
                {
                    sql = "UPDATE drugs SET "
                    + "provider_no = '" + this.getProviderNo() + "', "
                    + "demographic_no = " + this.getDemographicNo() + ", "
                    + "rx_date = '" + RxUtil.DateToString(this.getRxDate()) + "', "
                    + "end_date = '" + RxUtil.DateToString(this.getEndDate()) + "', "
                    + "BN = '" + this.getBrandName() + "', "
                    + "GCN_SEQNO = " + this.getGCN_SEQNO() + ", "
                    + "customName = '" + this.getCustomName() + "', "
                    + "takemin = " + this.getTakeMin() + ", "
                    + "takemax = " + this.getTakeMax() + ", "
                    + "freqcode = '" + this.getFrequencyCode() + "', "
                    + "duration = '" + this.getDuration() + "', "
                    + "durunit = '" + this.getDurationUnit() + "', "
                    + "quantity = '" + this.getQuantity() + "', "
                    + "repeat = " + this.getRepeat() + ", "
                    + "nosubs = " + this.getNosubsInt() + ", "
                    + "prn = " + this.getPrnInt() + ", "
                    + "special = '" + RxUtil.replace(this.getSpecial(), "'", "") + "' "
                    + "WHERE drugid = " + this.getDrugId();

                    db.RunSQL(sql);

                    b = true;
                }

                // close by conn
                db.CloseConn();

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }

            return b;
        }

        public boolean AddToFavorites(String providerNo, String favoriteName)
        {
            boolean b = false;

            Favorite fav = new Favorite(0, providerNo, favoriteName,
            this.getBrandName(), this.getGCN_SEQNO(), this.getCustomName(),
            this.getTakeMin(), this.getTakeMax(),
            this.getFrequencyCode(), this.getDuration(),
            this.getDurationUnit(), this.getQuantity(),
            this.getRepeat(), this.getNosubsInt(), this.getPrnInt(), this.getSpecial());

            return fav.Save();
        }
    }

    public class Favorite
    {
        int favoriteId;
        String providerNo;
        String favoriteName;
        String BN;
        int GCN_SEQNO;
        String customName;
        float takeMin;
        float takeMax;
        String frequencyCode;
        String duration;
        String durationUnit;
        String quantity;
        int repeat;
        boolean nosubs;
        boolean prn;
        String special;

        public Favorite(int favoriteId, String providerNo, String favoriteName,
            String BN, int GCN_SEQNO, String customName,
            float takeMin, float takeMax, String frequencyCode, String duration,
            String durationUnit, String quantity,
            int repeat, int nosubs, int prn, String special)
        {
            this.favoriteId = favoriteId;
            this.providerNo = providerNo;
            this.favoriteName = favoriteName;
            this.BN = BN;
            this.GCN_SEQNO = GCN_SEQNO;
            this.customName = customName;
            this.takeMin = takeMin;
            this.takeMax = takeMax;
            this.frequencyCode = frequencyCode;
            this.duration = duration;
            this.durationUnit = durationUnit;
            this.quantity = quantity;
            this.repeat = repeat;
            this.nosubs = RxUtil.IntToBool(nosubs);
            this.prn = RxUtil.IntToBool(prn);
            this.special = special;
        }

        public int getFavoriteId()
        {
            return this.favoriteId;
        }

        public String getProviderNo()
        {
            return this.providerNo;
        }

        public String getFavoriteName()
        {
            return this.favoriteName;
        }

        public void setFavoriteName(String RHS)
        {
            this.favoriteName = RHS;
        }

        public String getBN()
        {
            return this.BN;
        }

        public void setBN(String RHS)
        {
            this.BN = RHS;
        }

        public int getGCN_SEQNO()
        {
            return this.GCN_SEQNO;
        }

        public void setGCN_SEQNO(int RHS)
        {
            this.GCN_SEQNO = RHS;
        }

        public String getCustomName()
        {
            return this.customName;
        }

        public void setCustomName(String RHS)
        {
            this.customName = RHS;
        }

        public float getTakeMin()
        {
            return this.takeMin;
        }

        public void setTakeMin(float RHS)
        {
            this.takeMin = RHS;
        }

        public String getTakeMinString()
        {
            return RxUtil.FloatToString(this.takeMin);
        }

        public float getTakeMax()
        {
            return this.takeMax;
        }

        public void setTakeMax(float RHS)
        {
            this.takeMax = RHS;
        }

        public String getTakeMaxString()
        {
            return RxUtil.FloatToString(this.takeMax);
        }

        public String getFrequencyCode()
        {
            return this.frequencyCode;
        }

        public void setFrequencyCode(String RHS)
        {
            this.frequencyCode = RHS;
        }

        public String getDuration()
        {
            return this.duration;
        }

        public void setDuration(String RHS)
        {
            this.duration = RHS;
        }

        public String getDurationUnit()
        {
            return this.durationUnit;
        }

        public void setDurationUnit(String RHS)
        {
            this.durationUnit = RHS;
        }

        public String getQuantity()
        {
            return this.quantity;
        }

        public void setQuantity(String RHS)
        {
            this.quantity = RHS;
        }

        public int getRepeat()
        {
            return this.repeat;
        }

        public void setRepeat(int RHS)
        {
            this.repeat = RHS;
        }

        public boolean getNosubs()
        {
            return this.nosubs;
        }

        public void setNosubs(boolean RHS)
        {
            this.nosubs = RHS;
        }

        public int getNosubsInt()
        {
            if (this.getNosubs()==true)
            {
                return 1;
            } else
            {
                return 0;
            }
        }

        public boolean getPrn()
        {
            return this.prn;
        }

        public void setPrn(boolean RHS)
        {
            this.prn = RHS;
        }

        public int getPrnInt()
        {
            if (this.getPrn()==true)
            {
                return 1;
            } else
            {
                return 0;
            }
        }

        public String getSpecial()
        {
            return this.special;
        }

        public void setSpecial(String RHS)
        {
            this.special = RHS;
        }

        public boolean Save()
        {
            boolean b = false;

            // clean up fields
            if(this.takeMin > this.takeMax)
            {
                this.takeMax = this.takeMin;
            }

            try
            {
                DBHandler db = new DBHandler(DBHandler.OSCAR_DATA);
                ResultSet rs;
                String sql;

                if(this.getFavoriteId()==0)
                {
                    sql = "SELECT favoriteid FROM favorites WHERE "
                    + "provider_no = '" + this.getProviderNo() + "' AND "
                    + "favoritename = '" + this.getFavoriteName() + "' AND "
                    + "BN = '" + this.getBN() + "' AND "
                    + "GCN_SEQNO = " + this.getGCN_SEQNO() + " AND "
                    + "customName = '" + this.getCustomName() + "' AND "
                    + "takemin = " + this.getTakeMin() + " AND "
                    + "takemax = " + this.getTakeMax() + " AND "
                    + "freqcode = '" + this.getFrequencyCode() + "' AND "
                    + "duration = '" + this.getDuration() + "' AND "
                    + "durunit = '" + this.getDurationUnit() + "' AND "
                    + "quantity = '" + this.getQuantity() + "' AND "
                    + "repeat = " + this.getRepeat() + " AND "
                    + "nosubs = " + this.getNosubsInt() + " AND "
                    + "prn = " + this.getPrnInt() + " AND "
                    + "special = '" + RxUtil.replace(this.getSpecial(), "'", "") + "'";

                    rs = db.GetSQL(sql);

                    if(rs.next())
                    {
                        this.favoriteId = rs.getInt("favoriteid");
                    }

                    rs.close();

                    b = true;

                    if(this.getFavoriteId()==0)
                    {
                        sql = "INSERT INTO favorites (provider_no, favoritename, "
                        + "BN, GCN_SEQNO, customName, takemin, takemax, "
                        + "freqcode, duration, durunit, quantity, "
                        + "repeat, nosubs, prn, special) "
                        + "VALUES ('" + this.getProviderNo() + "', '" + this.getFavoriteName() + "', '"
                        + this.getBN() + "', " + this.getGCN_SEQNO() + ", '"
                        + this.getCustomName() + "', "
                        + this.getTakeMin() + ", " + this.getTakeMax() + ", '"
                        + this.getFrequencyCode() + "', '" + this.getDuration() + "', '"
                        + this.getDurationUnit() + "', '" + this.getQuantity() + "', "
                        + this.getRepeat() + ", " + this.getNosubsInt() + ", "
                        + this.getPrnInt() + ", '"
                        + RxUtil.replace(this.getSpecial(), "'", "") + "')";

                        db.RunSQL(sql);

                        sql = "SELECT Max(favoriteid) FROM favorites";

                        rs = db.GetSQL(sql);

                        if (rs.next())
                        {
                            this.favoriteId = rs.getInt(1);
                        }

                        rs.close();

                        b = true;
                    }

                } else
                {
                    sql = "UPDATE favorites SET "
                    + "provider_no = '" + this.getProviderNo() + "', "
                    + "favoritename = '" + this.getFavoriteName() + "', "
                    + "BN = '" + this.getBN() + "', "
                    + "GCN_SEQNO = " + this.getGCN_SEQNO() + ", "
                    + "customName = '" + this.getCustomName() + "', "
                    + "takemin = " + this.getTakeMin() + ", "
                    + "takemax = " + this.getTakeMax() + ", "
                    + "freqcode = '" + this.getFrequencyCode() + "', "
                    + "duration = '" + this.getDuration() + "', "
                    + "durunit = '" + this.getDurationUnit() + "', "
                    + "quantity = '" + this.getQuantity() + "', "
                    + "repeat = " + this.getRepeat() + ", "
                    + "nosubs = " + this.getNosubsInt() + ", "
                    + "prn = " + this.getPrnInt() + ", "
                    + "special = '" + RxUtil.replace(this.getSpecial(), "'", "") + "' "
                    + "WHERE favoriteid = " + this.getFavoriteId();

                    db.RunSQL(sql);

                    b = true;
                }

                // close by conn
                db.CloseConn();

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }

            return b;
        }
    }
}
