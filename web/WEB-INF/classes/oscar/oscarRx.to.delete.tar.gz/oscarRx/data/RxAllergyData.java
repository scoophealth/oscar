package oscar.oscarRx.data;

import oscar.oscarDB.*;
import oscar.oscarRx.util.*;
import java.util.*;
import java.sql.*;

public class RxAllergyData
{
    public Allergy[] AllergySearch(String searchString,
        boolean type5, boolean type4, boolean type3, boolean type2, boolean type1)
    {
        Allergy[] arr = {};

        if(searchString.length()>0 && (type5 || type4 || type3 || type2 || type1))
        {
            ArrayList lst = new ArrayList();
            Allergy allergy;

            String search = oscar.oscarRx.util.RxUtil.replace(searchString, "'", "''");

            try
            {
                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;
                String sql;

                sql = "SELECT * FROM CDAMPICK WHERE DESCRIPTION LIKE '" + search + "%' ";
                sql += "AND TYPECODE IN (";

                if(type5)
                {
                    sql += "5, ";
                }
                if(type4)
                {
                    sql += "4, ";
                }
                if(type3)
                {
                    sql += "3, ";
                }
                if(type2)
                {
                    sql += "2, ";
                }
                if(type1)
                {
                    sql += "1, ";
                }

                sql += "0)";

                rs = db.GetSQL(sql);

                while(rs.next())
                {
                    allergy = new Allergy(rs.getInt("ID"), rs.getString("DESCRIPTION"),
                        rs.getInt("HICL_SEQNO"), rs.getInt("HIC_SEQNO"),
                        rs.getInt("AGCSP"), rs.getInt("AGCCS"), rs.getInt("TYPECODE"));
                    lst.add(allergy);
                }

                rs.close();
                db.CloseConn();

                arr = (Allergy[])lst.toArray(arr);

            } catch (SQLException e)
            {
                System.out.println(e.getMessage());
            }
        }

	return arr;
    }

    public Allergy getAllergy(int PickID)
    {
        Allergy allergy = null;

        try
        {
            DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
            ResultSet rs;
            String sql = "SELECT * FROM CDAMPICK WHERE ID = " + PickID;

            rs = db.GetSQL(sql);

            if (rs.next())
            {
                allergy = new Allergy(PickID, rs.getString("DESCRIPTION"),
                    rs.getInt("HICL_SEQNO"), rs.getInt("HIC_SEQNO"),
                    rs.getInt("AGCSP"), rs.getInt("AGCCS"), rs.getInt("TYPECODE"));
            }

            rs.close();
            db.CloseConn();

        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }

        return allergy;
    }

    public Allergy getAllergy(String DESCRIPTION, int HICL_SEQNO, int HIC_SEQNO,
                int AGCSP, int AGCCS, int TYPECODE)
    {
        return new Allergy(DESCRIPTION, HICL_SEQNO, HIC_SEQNO, AGCSP, AGCCS, TYPECODE);
    }

    public Reaction[] getReactions(Integer[] GCN_SEQArray, RxPatientData.Patient patient)
    {
        Reaction[] arr = {};

        try
        {
            if(GCN_SEQArray.length>0 && patient.getAllergies().length>0)
            {
                ArrayList reactions = new ArrayList();

                int i;

                int GCN_SEQNO;
                int HICL_SEQNO;
                int HIC_SEQNO;
                int AGCSP;
                int AGCCS;

                Allergy allergy;

                ArrayList allergies = new ArrayList();
                for(i=0; i<patient.getAllergies().length; i++)
                {
                    allergies.add(patient.getAllergies()[i].getAllergy());
                }

                DBHandler db = new DBHandler(DBHandler.IDDF_DATA);
                ResultSet rs;
                String sql;

                sql = "SELECT RGCNSEQ3.GCN_SEQNO, RGCNSEQ3.HICL_SEQNO, RHICL1.HIC_SEQN, "
                    + "RHICL1.HIC_SEQN, RDAMMA2.DAM_AGCSP, RDAMMA2.DAM_AGCCS "
                    + "FROM RGCNSEQ3 LEFT JOIN RHICL1 ON RGCNSEQ3.HICL_SEQNO = RHICL1.HICL_SEQNO "
                    + "LEFT JOIN RDAMMA2 ON RHICL1.HIC_SEQN = RDAMMA2.HIC_SEQN "
                    + "WHERE RGCNSEQ3.GCN_SEQNO IN (" + RxUtil.joinArray(GCN_SEQArray) + ")";
                rs = db.GetSQL(sql);

                while(rs.next())
                {
                    GCN_SEQNO = rs.getInt("GCN_SEQNO");
                    HICL_SEQNO = rs.getInt("HICL_SEQNO");
                    HIC_SEQNO = rs.getInt("HIC_SEQN");
                    AGCSP = rs.getInt("DAM_AGCSP");
                    AGCCS = rs.getInt("DAM_AGCCS");

                    for(i=0;i<allergies.size();i++)
                    {
                        allergy = (Allergy)allergies.get(i);

                        if(HICL_SEQNO == allergy.getHICL_SEQNO())
                        {
                            reactions.add(new Reaction(GCN_SEQNO, allergy, 1));
                        }
                        else
                        {
                            if(HIC_SEQNO == allergy.getHIC_SEQNO())
                            {
                                reactions.add(new Reaction(GCN_SEQNO, allergy, 1));
                            }
                            else
                            {
                                if(AGCSP == allergy.getAGCSP())
                                {
                                    reactions.add(new Reaction(GCN_SEQNO, allergy, 2));
                                }
                                else
                                {
                                    if(AGCCS == allergy.getAGCCS())
                                    {
                                        reactions.add(new Reaction(GCN_SEQNO, allergy, 3));
                                    }
                                }
                            }
                        }
                    }
                }

                rs.close();
                db.CloseConn();

                arr = (Reaction[])reactions.toArray(arr);
            }
        } catch (SQLException e)
        {
            e.printStackTrace(System.out);
        }

        return arr;
    }

    public class Allergy
    {
        int PickID;
        String DESCRIPTION;
        int HICL_SEQNO;
        int HIC_SEQNO;
        int AGCSP;
        int AGCCS;
        int TYPECODE;

        public Allergy(int PickID, String DESCRIPTION, int HICL_SEQNO, int HIC_SEQNO,
                int AGCSP, int AGCCS, int TYPECODE)
        {
            this.PickID = PickID;
            this.DESCRIPTION = DESCRIPTION;
            this.HICL_SEQNO = HICL_SEQNO;
            this.HIC_SEQNO = HIC_SEQNO;
            this.AGCSP = AGCSP;
            this.AGCCS = AGCCS;
            this.TYPECODE = TYPECODE;
        }

        public Allergy(String DESCRIPTION, int HICL_SEQNO, int HIC_SEQNO,
                int AGCSP, int AGCCS, int TYPECODE)
        {
            this(0, DESCRIPTION, HICL_SEQNO, HIC_SEQNO, AGCSP, AGCCS, TYPECODE);
        }

        public int getPickID()
        {
            return this.PickID;
        }
        public void setPickID(int RHS)
        {
            this.PickID=RHS;
        }

        public String getDESCRIPTION()
        {
            return this.DESCRIPTION;
        }

        public int getHICL_SEQNO()
        {
            return this.HICL_SEQNO;
        }

        public int getHIC_SEQNO()
        {
            return this.HIC_SEQNO;
        }

        public int getAGCSP()
        {
            return this.AGCSP;
        }

        public int getAGCCS()
        {
            return this.AGCCS;
        }

        public int getTYPECODE()
        {
            return this.TYPECODE;
        }

        public String getAllergyDisp()
        {
            return this.DESCRIPTION + " (" + this.getTypeDesc() + ")";
        }

        public String getTypeDesc()
        {
            String s;

            switch(this.TYPECODE)
            {
                case 1:
                    s = "Brand Name";
                    break;
                case 2:
                    s = "Generic Name";
                    break;
                case 3:
                    s = "Ingredient";
                    break;
                case 4:
                    s = "Allergy Group";
                    break;
                case 5:
                    s = "Cross-Sensitive Allergy Group";
                    break;
                default:
                    s = "";
            }
            return s;
        }
    }

    public class Reaction
    {
        int GCN_SEQNO;
        Allergy allergy;
        int severity;

        public Reaction(int GCN_SEQNO, Allergy allergy, int severity)
        {
            this.GCN_SEQNO = GCN_SEQNO;
            this.allergy = allergy;
            this.severity = severity;
        }

        public int getGCN_SEQNO()
        {
            return this.GCN_SEQNO;
        }
        public String getGenericName()
        {
            return new RxDrugData().getGenericName(this.GCN_SEQNO);
        }
        public Allergy getAllergy()
        {
            return this.allergy;
        }
        public int getSeverity()
        {
            return severity;
        }
    }
}